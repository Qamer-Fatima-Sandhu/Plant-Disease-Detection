'use strict';

// ======================= BACKEND API =======================
const API_BASE = 'http://localhost:5000/api';

let authToken = localStorage.getItem('token');
let currentUser = null;
let currentPage = null;

// ── DOM helpers ──────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
function esc(s) { return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function fmtDate(d) { if (!d) return '—'; try { return new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }); } catch(e) { return d; } }
function fmtMoney(v) { return '$' + Number(v || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
function initials(n) { return (n || 'U').split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase(); }
function nights(cin, cout) { return Math.max(1, Math.round((new Date(cout) - new Date(cin)) / 86400000)); }
function statusBadge(s) {
  const m = { Available: 'bdg-green', Occupied: 'bdg-blue', Maintenance: 'bdg-amber', Confirmed: 'bdg-blue', 'Checked In': 'bdg-green', Completed: 'bdg-purple', Cancelled: 'bdg-red', Paid: 'bdg-green', Pending: 'bdg-amber', Failed: 'bdg-red' };
  return `<span class="badge ${m[s] || 'bdg-blue'}">${esc(s)}</span>`;
}
function roleBadge(r) { const m = { admin: 'bdg-gold', receptionist: 'bdg-blue', customer: 'bdg-green' }; return `<span class="badge ${m[(r||'').toLowerCase()] || 'bdg-blue'}">${esc(r)}</span>`; }
function av(name, size = 30, fontSize = 11) { return `<div class="ava" style="width:${size}px;height:${size}px;font-size:${fontSize}px;background:var(--gold);border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-weight:700;color:#1a0a00;flex-shrink:0;">${initials(name)}</div>`; }
function today() { return new Date().toISOString().split('T')[0]; }
function tomorrow() { const d = new Date(); d.setDate(d.getDate() + 1); return d.toISOString().split('T')[0]; }

// ── TOAST & MODAL ────────────────────────────────────────────────────────
function toast(msg, type = 'info') {
  const icons = { success: 'fa-check-circle', error: 'fa-times-circle', info: 'fa-info-circle', warning: 'fa-exclamation-triangle' };
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.innerHTML = `<i class="fas ${icons[type]}"></i><span>${msg}</span>`;
  $('toastBox').appendChild(t);
  setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 300); }, 3200);
}
function showModal(title, body) {
  $('modalContent').innerHTML = `<div class="modal-title">${title}</div>${body}`;
  $('modalBg').classList.add('on');
}
function hideModal() { $('modalBg').classList.remove('on'); }
$('modalBg').addEventListener('click', (e) => { if (e.target === $('modalBg')) hideModal(); });
$('modalClose').addEventListener('click', hideModal);

// ── API CALL ─────────────────────────────────────────────────────────────
async function apiCall(method, path, body = null) {
  const headers = { 'Content-Type': 'application/json' };
  if (authToken) headers['Authorization'] = `Bearer ${authToken}`;
  try {
    const res = await fetch(`${API_BASE}${path}`, { method, headers, body: body ? JSON.stringify(body) : undefined });
    const contentType = res.headers.get('content-type');
    if (!contentType || !contentType.includes('application/json')) {
      const text = await res.text();
      console.error('Non-JSON response:', text.substring(0, 200));
      throw new Error('Server error – please check backend logs');
    }
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Request failed');
    return data;
  } catch (err) {
    console.error('API error:', err);
    throw err;
  }
}

// ── AUTH ─────────────────────────────────────────────────────────────────
async function doLogin(e) {
  e.preventDefault();
  const username = $('lUser').value.trim();
  const password = $('lPass').value;
  if (!username || !password) { showErr('Please fill all fields'); return; }
  try {
    const data = await apiCall('POST', '/auth/login', { username, password });
    authToken = data.token;
    localStorage.setItem('token', authToken);
    currentUser = { ...data.user, role: (data.user.role || 'customer').toLowerCase() };
    enterApp();
  } catch (err) { showErr(err.message); }
}
async function doSignup(e) {
  e.preventDefault();
  const fullName = $('sName').value.trim(), username = $('sUser').value.trim(),
        email = $('sEmail').value.trim(), password = $('sPass').value, phone = $('sPhone').value.trim();
  if (!fullName || !username || !email || !password) { showErr('All fields required'); return; }
  try {
    await apiCall('POST', '/auth/register', { fullName, username, email, password, phone });
    toast('Account created! Please sign in.', 'success');
    switchTab('login');
    $('lUser').value = username;
  } catch (err) { showErr(err.message); }
}
function logout() {
  currentUser = null; authToken = null;
  localStorage.removeItem('token');
  $('app').style.display = 'none';
  $('authWrap').style.display = 'flex';
  $('lUser').value = ''; $('lPass').value = '';
  $('authErr').classList.remove('on');
}
function switchTab(tab) {
  $('tabL').classList.toggle('on', tab === 'login');
  $('tabS').classList.toggle('on', tab === 'signup');
  $('fLogin').style.display = tab === 'login' ? '' : 'none';
  $('fSignup').style.display = tab === 'signup' ? '' : 'none';
  $('aslider').classList.toggle('r', tab === 'signup');
  $('authErr').classList.remove('on');
}
function fillDemo(user, pass) { $('lUser').value = user; $('lPass').value = pass; }
function showErr(msg) { const e = $('authErr'); e.textContent = msg; e.classList.add('on'); }

// ── SIDEBAR ───────────────────────────────────────────────────────────────
const NAV = {
  admin: [
    { s: 'Overview' }, { p: 'dashboard', i: 'fa-gauge-high', l: 'Dashboard' }, { p: 'rooms', i: 'fa-door-open', l: 'Rooms' },
    { s: 'Operations' }, { p: 'bookings', i: 'fa-calendar-check', l: 'Bookings' }, { p: 'guests', i: 'fa-users', l: 'Guests' },
    { s: 'Finance' }, { p: 'payments', i: 'fa-credit-card', l: 'Payments' }, { p: 'reports', i: 'fa-chart-bar', l: 'Reports' },
    { s: 'Admin' }, { p: 'staff', i: 'fa-user-tie', l: 'Staff' }, { p: 'complaints-admin', i: 'fa-flag', l: 'Complaints' }
  ],
  receptionist: [
    { s: 'Overview' }, { p: 'dashboard', i: 'fa-gauge-high', l: 'Dashboard' }, { p: 'rooms', i: 'fa-door-open', l: 'Rooms' },
    { s: 'Operations' }, { p: 'bookings', i: 'fa-calendar-check', l: 'Bookings' }, { p: 'guests', i: 'fa-users', l: 'Guests' },
    { s: 'Finance' }, { p: 'payments', i: 'fa-credit-card', l: 'Payments' }
  ],
  customer: [
    { s: 'My Account' }, { p: 'my-dash', i: 'fa-house', l: 'Home' }, { p: 'browse', i: 'fa-search', l: 'Browse Rooms' },
    { p: 'my-bookings', i: 'fa-calendar-check', l: 'My Bookings' },
    { s: 'Manage' }, { p: 'wallet', i: 'fa-wallet', l: 'Wallet' },
    { p: 'profile', i: 'fa-user-circle', l: 'My Profile' }, { p: 'complaints', i: 'fa-comment-dots', l: 'Complaints' },
    { p: 'notifs', i: 'fa-bell', l: 'Notifications' },
    { s: 'Help' }, { p: 'faqs', i: 'fa-circle-question', l: 'FAQs' }, { p: 'contact', i: 'fa-headset', l: 'Contact Us' }
  ]
};

function buildSidebar() {
  const role = currentUser?.role || 'customer';
  const items = NAV[role] || NAV.customer;
  const nav = $('sbNav');
  nav.innerHTML = '';
  items.forEach(it => {
    if (it.s) { nav.innerHTML += `<div class="sb-sec">${it.s}</div>`; return; }
    nav.innerHTML += `<div class="ni ${currentPage === it.p ? 'on' : ''}" data-page="${it.p}"><i class="fas ${it.i}"></i><span>${it.l}</span></div>`;
  });
  document.querySelectorAll('.ni').forEach(el => el.addEventListener('click', () => { go(el.dataset.page); if (window.innerWidth < 900) closeSb(); }));
  const name = currentUser?.fullName || 'Guest';
  $('sbAv').textContent = initials(name);
  $('sbName').textContent = name;
  $('sbRole').textContent = role;
  $('walletTopbar').innerHTML = `<i class="fas fa-wallet"></i> ${fmtMoney(currentUser?.wallet || 0)}`;
}
function openSb() { $('sidebar').classList.add('open'); $('sbOv').classList.add('on'); }
function closeSb() { $('sidebar').classList.remove('open'); $('sbOv').classList.remove('on'); }
window.addEventListener('resize', () => { if (window.innerWidth >= 900) closeSb(); });

// ── ROUTER ────────────────────────────────────────────────────────────────
async function go(page) {
  currentPage = page;
  buildSidebar();
  const container = $('mainArea');
  container.innerHTML = '<div style="padding:40px;text-align:center"><div class="spin"></div></div>';
  try {
    if (page === 'dashboard') await renderDashboard(container);
    else if (page === 'rooms') await renderRooms(container);
    else if (page === 'bookings') await renderBookings(container);
    else if (page === 'guests') await renderGuests(container);
    else if (page === 'payments') await renderPayments(container);
    else if (page === 'reports') await renderReports(container);
    else if (page === 'staff') await renderStaff(container);
    else if (page === 'complaints-admin') await renderAdminComplaints(container);
    else if (page === 'my-dash') await renderMyDashboard(container);
    else if (page === 'browse') await renderBrowseRooms(container);
    else if (page === 'my-bookings') await renderMyBookings(container);
    else if (page === 'wallet') await renderWallet(container);
    else if (page === 'profile') await renderProfile(container);
    else if (page === 'complaints') await renderComplaints(container);
    else if (page === 'notifs') await renderNotifications(container);
    else if (page === 'faqs') renderFaqs(container);
    else if (page === 'contact') renderContact(container);
    else container.innerHTML = '<div class="page"><div class="card"><p>Page under construction</p></div></div>';
  } catch (err) {
    console.error('Page render error:', err);
    container.innerHTML = `<div class="page"><div class="card"><div class="empty"><i class="fas fa-exclamation-triangle"></i><p>${esc(err.message)}</p></div></div></div>`;
  }
}

// ── DASHBOARD (admin/receptionist) ───────────────────────────────────────
async function renderDashboard(container) {
  const [stats, recent] = await Promise.all([
    apiCall('GET', '/rooms/stats'),
    apiCall('GET', '/bookings/recent')
  ]);
  const occ = stats.occupied || 0, avail = stats.available || 0, tot = stats.total || 0, maint = stats.maintenance || 0;
  const pct = tot ? Math.round(occ / tot * 100) : 0;
  const circ = 2 * Math.PI * 42, dash = circ - (pct / 100) * circ;

  const recentRows = (recent || []).map(b => `
    <tr>
      <td><div style="display:flex;align-items:center;gap:7px">${av(b.fullName,26,9)}<span>${esc(b.fullName)}</span></div></td>
      <td><span style="font-weight:500">#${esc(b.roomNumber)}</span> <span style="color:var(--text3);font-size:11px">· ${esc(b.roomType)}</span></td>
      <td>${fmtDate(b.checkIn)}</td>
      <td>${fmtDate(b.checkOut)}</td>
      <td style="font-weight:500">${fmtMoney(b.total)}</td>
      <td>${statusBadge(b.status)}</td>
      <td><button class="btn btn-ghost btn-sm btn-icon" onclick="viewBkModal(${b.id})"><i class="fas fa-eye"></i></button></td>
    </tr>`).join('');

  container.innerHTML = `<div class="page">
    <div class="ph">
      <div><h1>Good ${new Date().getHours() < 12 ? 'morning' : 'afternoon'}, ${esc(currentUser.fullName.split(' ')[0])}</h1>
      <p>${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p></div>
      <div class="phr">
        <button class="btn btn-primary" onclick="openNewBkModal()"><i class="fas fa-plus"></i> New Booking</button>
      </div>
    </div>
    <div class="sg">
      <div class="sc blue"><div class="sico blue"><i class="fas fa-door-closed"></i></div><div class="slabel">Occupied</div><div class="sval" style="color:var(--blue)">${occ}</div><div class="ssub">of ${tot} rooms</div></div>
      <div class="sc green"><div class="sico green"><i class="fas fa-circle-check"></i></div><div class="slabel">Available</div><div class="sval" style="color:var(--green)">${avail}</div><div class="ssub">ready to book</div></div>
      <div class="sc amber"><div class="sico amber"><i class="fas fa-wrench"></i></div><div class="slabel">Maintenance</div><div class="sval">${maint}</div><div class="ssub">under repair</div></div>
      <div class="sc gold"><div class="sico gold"><i class="fas fa-building"></i></div><div class="slabel">Total Rooms</div><div class="sval" style="color:var(--gold-light)">${tot}</div><div class="ssub">in property</div></div>
    </div>
    <div class="quick-grid">
      ${['bookings','rooms','guests','reports','payments'].map(p => `<div class="qbtn" onclick="go('${p}')"><i class="fas ${p==='bookings'?'fa-calendar-check':p==='rooms'?'fa-door-open':p==='guests'?'fa-users':p==='reports'?'fa-chart-bar':'fa-receipt'}" style="color:var(--gold-light)"></i>${p.charAt(0).toUpperCase()+p.slice(1)}</div>`).join('')}
    </div>
    <div class="g21">
      <div class="card">
        <div class="ch"><span class="ctitle">Recent Bookings</span><span class="badge bdg-blue">${(recent||[]).length} recent</span></div>
        <div class="tw"><table class="dt">
          <thead><tr><th>Guest</th><th>Room</th><th>Check-in</th><th>Check-out</th><th>Amount</th><th>Status</th><th></th></tr></thead>
          <tbody>${recentRows || `<tr><td colspan="7"><div class="empty"><i class="fas fa-calendar-xmark"></i><p>No bookings yet</p></div></td></tr>`}</tbody>
        </table></div>
        <div style="margin-top:10px;text-align:right"><button class="btn btn-outline btn-sm" onclick="go('bookings')">View all <i class="fas fa-arrow-right"></i></button></div>
      </div>
      <div class="card">
        <div class="ch"><span class="ctitle">Occupancy</span></div>
        <div style="display:flex;flex-direction:column;align-items:center;gap:14px;padding:8px 0">
          <div style="position:relative;width:100px;height:100px">
            <svg width="100" height="100" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="42" fill="none" stroke="var(--bg4)" stroke-width="9"/>
              <circle cx="50" cy="50" r="42" fill="none" stroke="var(--gold)" stroke-width="9"
                stroke-dasharray="${circ.toFixed(2)}" stroke-dashoffset="${dash.toFixed(2)}"
                stroke-linecap="round" transform="rotate(-90 50 50)"/>
            </svg>
            <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
              <span style="font-size:18px;font-weight:700">${pct}%</span>
              <span style="font-size:9px;color:var(--text3);text-transform:uppercase">occupied</span>
            </div>
          </div>
          <div style="width:100%;display:flex;flex-direction:column;gap:7px;padding:0 4px">
            ${[{l:'Available',v:avail,c:'green'},{l:'Occupied',v:occ,c:'blue'},{l:'Maintenance',v:maint,c:'amber'}].map(x=>
              `<div style="display:flex;justify-content:space-between;align-items:center;font-size:12px">
                <div style="display:flex;align-items:center;gap:7px"><div class="rleg-dot" style="background:var(--${x.c})"></div><span style="color:var(--text2)">${x.l}</span></div>
                <span style="font-weight:500">${x.v}</span>
              </div>`).join('')}
          </div>
        </div>
      </div>
    </div>
  </div>`;
}

// ── ROOMS ─────────────────────────────────────────────────────────────────
async function renderRooms(container) {
  const rooms = await apiCall('GET', '/rooms');
  const floors = [...new Set(rooms.map(r => r.floor))].sort((a,b) => a-b);
  const grouped = {};
  rooms.forEach(r => { if (!grouped[r.floor]) grouped[r.floor] = []; grouped[r.floor].push(r); });

  const tableRows = rooms.map(r => `
    <tr data-room-number="${r.number}" data-room-type="${r.type}" data-room-status="${r.status}">
      <td style="font-weight:500">#${esc(r.number)}</td>
      <td>${esc(r.type)}</td>
      <td>${r.floor}</td>
      <td style="color:var(--gold-light);font-weight:500">${fmtMoney(r.price)}</td>
      <td style="color:var(--text2);font-size:12px">${esc(r.amenities || '—')}</td>
      <td>${statusBadge(r.status)}</td>
      <td>
        <div style="display:flex;gap:5px">
          <button class="btn btn-ghost btn-sm btn-icon" onclick="viewRoomModal(${r.id})"><i class="fas fa-eye"></i></button>
          ${currentUser.role !== 'customer' ? `<button class="btn btn-ghost btn-sm btn-icon" onclick="editRoomModal(${r.id})"><i class="fas fa-pencil"></i></button>` : ''}
          ${currentUser.role === 'admin' ? `<button class="btn btn-danger btn-sm btn-icon" onclick="delRoom(${r.id})"><i class="fas fa-trash"></i></button>` : ''}
        </div>
      </td>
    </tr>`).join('');

  container.innerHTML = `<div class="page">
    <div class="ph">
      <div><h1>Room Management</h1><p>${rooms.length} rooms across ${floors.length} floors</p></div>
      <div class="phr">${currentUser.role === 'admin' ? `<button class="btn btn-primary" onclick="openAddRoomModal()"><i class="fas fa-plus"></i> Add Room</button>` : ''}</div>
    </div>
    <div class="sg">
      ${[{l:'Total',v:rooms.length,c:'gold',i:'fa-building'},{l:'Available',v:rooms.filter(r=>r.status==='Available').length,c:'green',i:'fa-circle-check'},{l:'Occupied',v:rooms.filter(r=>r.status==='Occupied').length,c:'blue',i:'fa-door-closed'},{l:'Maintenance',v:rooms.filter(r=>r.status==='Maintenance').length,c:'amber',i:'fa-wrench'}].map(s=>`
        <div class="sc ${s.c}"><div class="sico ${s.c}"><i class="fas ${s.i}"></i></div><div class="slabel">${s.l}</div><div class="sval">${s.v}</div></div>`).join('')}
    </div>
    <div class="card">
      <div class="ch"><span class="ctitle">Floor Plan</span>
        <div class="rleg">
          ${[{l:'Available',c:'green'},{l:'Occupied',c:'blue'},{l:'Maintenance',c:'amber'}].map(x=>`<div class="rleg-item"><div class="rleg-dot" style="background:var(--${x.c})"></div>${x.l}</div>`).join('')}
        </div>
      </div>
      ${floors.map(f => `
        <div class="room-floor">
          <div class="floor-lbl">Floor ${f}</div>
          <div class="room-grid">
            ${(grouped[f]||[]).map(r=>`<div class="rchip ${(r.status||'').toLowerCase()}" onclick="viewRoomModal(${r.id})" title="${esc(r.type)} · ${esc(r.status)}">${esc(r.number)}<small>${esc((r.type||'').split(' ')[0])}</small></div>`).join('')}
          </div>
        </div>`).join('')}
    </div>
    <div class="card">
      <div class="ch"><span class="ctitle">All Rooms</span>
        <div class="sbar">
          <div class="srch"><i class="fas fa-search"></i><input type="text" id="rSearch" placeholder="Search…" oninput="filterRooms()"/></div>
          <select class="fsel" id="rFilter" onchange="filterRooms()"><option value="">All Status</option><option>Available</option><option>Occupied</option><option>Maintenance</option></select>
        </div>
      </div>
      <div class="tw"><table class="dt">
        <thead><tr><th>Room</th><th>Type</th><th>Floor</th><th>Price/Night</th><th>Amenities</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody id="rTbody">${tableRows}</tbody>
      </table></div>
    </div>
  </div>`;
}

window.filterRooms = function() {
  const q = ($('rSearch')?.value || '').toLowerCase();
  const f = ($('rFilter')?.value || '').toLowerCase();
  document.querySelectorAll('#rTbody tr').forEach(tr => {
    const text = tr.textContent.toLowerCase();
    const statusMatch = !f || (tr.dataset.roomStatus || '').toLowerCase() === f;
    tr.style.display = (!q || text.includes(q)) && statusMatch ? '' : 'none';
  });
};

window.viewRoomModal = async (id) => {
  try {
    const r = await apiCall('GET', `/rooms/${id}`);
    showModal(`Room #${esc(r.number)}`, `
      <div class="g2" style="margin-bottom:16px">
        ${[['Type',r.type],['Floor',r.floor],['Price/Night',fmtMoney(r.price)],['Amenities',r.amenities||'—'],['Status',statusBadge(r.status)]].map(([k,v])=>`
          <div style="padding:10px;background:var(--bg3);border-radius:8px">
            <div style="font-size:10px;color:var(--text3);margin-bottom:3px">${k}</div>
            <div style="font-weight:500">${v}</div>
          </div>`).join('')}
      </div>
      ${currentUser.role !== 'customer' && r.status === 'Available' ? `<button class="btn btn-primary" style="width:100%" onclick="hideModal();openNewBkModal(${r.id})"><i class="fas fa-calendar-plus"></i> Book this room</button>` : ''}
      ${currentUser.role === 'customer' && r.status === 'Available' ? `<button class="btn btn-primary" style="width:100%" onclick="hideModal();openCustBkModal(${r.id})"><i class="fas fa-calendar-plus"></i> Book this room</button>` : ''}`);
  } catch(err) { toast(err.message, 'error'); }
};

window.openAddRoomModal = () => {
  showModal('<i class="fas fa-plus" style="color:var(--gold)"></i> Add Room', `
    <div class="fgrid">
      <div class="fg"><label>Room Number</label><input type="number" id="arNo" placeholder="301"/></div>
      <div class="fg"><label>Floor</label><input type="number" id="arFloor" placeholder="3"/></div>
      <div class="fg"><label>Type</label><select id="arType"><option>Standard</option><option>Deluxe Twin</option><option>Deluxe King</option><option>Suite</option><option>Penthouse</option></select></div>
      <div class="fg"><label>Price/Night ($)</label><input type="number" id="arPrice" placeholder="150" step="0.01"/></div>
      <div class="fg full"><label>Amenities</label><input type="text" id="arAmen" placeholder="WiFi, TV, Balcony…"/></div>
    </div>
    <div class="fa-row"><button class="btn btn-outline" onclick="hideModal()">Cancel</button><button class="btn btn-primary" onclick="submitAddRoom()"><i class="fas fa-check"></i> Add</button></div>`);
};

window.submitAddRoom = async () => {
  const number = +$('arNo').value, floor = +$('arFloor').value, type = $('arType').value, price = +$('arPrice').value, amenities = $('arAmen').value;
  if (!number || !price) { toast('Number and price required', 'error'); return; }
  try {
    await apiCall('POST', '/rooms', { number, floor, type, price, amenities });
    toast('Room added!', 'success'); hideModal(); go('rooms');
  } catch (err) { toast(err.message, 'error'); }
};

window.editRoomModal = async (id) => {
  try {
    const r = await apiCall('GET', `/rooms/${id}`);
    showModal(`<i class="fas fa-pencil" style="color:var(--gold)"></i> Edit Room #${r.number}`, `
      <div class="fgrid">
        <div class="fg"><label>Type</label><select id="erType">${['Standard','Deluxe Twin','Deluxe King','Suite','Penthouse'].map(t=>`<option ${t===r.type?'selected':''}>${t}</option>`).join('')}</select></div>
        <div class="fg"><label>Price ($)</label><input type="number" id="erPrice" value="${r.price}" step="0.01"/></div>
        <div class="fg"><label>Status</label><select id="erStatus">${['Available','Occupied','Maintenance'].map(s=>`<option ${s===r.status?'selected':''}>${s}</option>`).join('')}</select></div>
        <div class="fg"><label>Floor</label><input type="number" id="erFloor" value="${r.floor}"/></div>
        <div class="fg full"><label>Amenities</label><input type="text" id="erAmen" value="${esc(r.amenities||'')}"/></div>
      </div>
      <div class="fa-row"><button class="btn btn-outline" onclick="hideModal()">Cancel</button><button class="btn btn-primary" onclick="submitEditRoom(${id})"><i class="fas fa-check"></i> Save</button></div>`);
  } catch(err) { toast(err.message, 'error'); }
};

window.submitEditRoom = async (id) => {
  try {
    const type = $('erType').value, price = +$('erPrice').value, status = $('erStatus').value, floor = +$('erFloor').value, amenities = $('erAmen').value;
    await apiCall('PUT', `/rooms/${id}`, { type, price, status, floor, amenities });
    toast('Room updated!', 'success'); hideModal(); go('rooms');
  } catch(err) { toast(err.message, 'error'); }
};

window.delRoom = async (id) => {
  if (!confirm('Delete this room?')) return;
  try {
    await apiCall('DELETE', `/rooms/${id}`);
    toast('Room deleted', 'warning'); go('rooms');
  } catch(err) { toast(err.message, 'error'); }
};

// ── BOOKINGS (admin/receptionist) ─────────────────────────────────────────
async function renderBookings(container) {
  const bookings = await apiCall('GET', '/bookings');

  const tableRows = (bookings || []).slice().reverse().map(b => `
    <tr>
      <td style="color:var(--text3);font-size:11px">#${b.id}</td>
      <td><div style="display:flex;align-items:center;gap:7px">${av(b.fullName,26,9)}<span>${esc(b.fullName)}</span></div></td>
      <td><span style="font-weight:500">#${esc(b.roomNumber)}</span> <span style="color:var(--text3);font-size:11px">· ${esc(b.roomType)}</span></td>
      <td>${fmtDate(b.checkIn)}</td>
      <td>${fmtDate(b.checkOut)}</td>
      <td style="font-weight:500">${fmtMoney(b.total)}</td>
      <td>${statusBadge(b.status)}</td>
      <td>
        <div style="display:flex;gap:4px">
          <button class="btn btn-ghost btn-sm btn-icon" onclick="viewBkModal(${b.id})"><i class="fas fa-eye"></i></button>
          ${b.status === 'Confirmed' ? `<button class="btn btn-success btn-sm" onclick="doCheckIn(${b.id})" title="Check In"><i class="fas fa-arrow-right-to-bracket"></i></button>` : ''}
          ${b.status === 'Checked In' ? `<button class="btn btn-outline btn-sm" onclick="doCheckOut(${b.id})" title="Check Out"><i class="fas fa-arrow-right-from-bracket"></i></button>` : ''}
          ${['Confirmed','Checked In'].includes(b.status) ? `<button class="btn btn-danger btn-sm btn-icon" onclick="doCancelBk(${b.id})"><i class="fas fa-times"></i></button>` : ''}
        </div>
      </td>
    </tr>`).join('');

  container.innerHTML = `<div class="page">
    <div class="ph">
      <div><h1>Bookings</h1><p>${(bookings||[]).length} total reservations</p></div>
      <div class="phr"><button class="btn btn-primary" onclick="openNewBkModal()"><i class="fas fa-plus"></i> New Booking</button></div>
    </div>
    <div class="sg">
      ${['Confirmed','Checked In','Completed','Cancelled'].map(s => {
        const cnt = (bookings||[]).filter(b => b.status === s).length;
        const c = {Confirmed:'blue','Checked In':'green',Completed:'purple',Cancelled:'red'}[s];
        return `<div class="sc ${c}"><div class="sico ${c}"><i class="fas fa-calendar"></i></div><div class="slabel">${s}</div><div class="sval">${cnt}</div></div>`;
      }).join('')}
    </div>
    <div class="card">
      <div class="ch"><span class="ctitle">All Bookings</span>
        <div class="sbar">
          <div class="srch"><i class="fas fa-search"></i><input type="text" id="bSearch" placeholder="Search guest, room…" oninput="filterBks()"/></div>
          <select class="fsel" id="bFilter" onchange="filterBks()"><option value="">All Status</option><option>Confirmed</option><option>Checked In</option><option>Completed</option><option>Cancelled</option></select>
        </div>
      </div>
      <div class="tw"><table class="dt">
        <thead><tr><th>ID</th><th>Guest</th><th>Room</th><th>Check-in</th><th>Check-out</th><th>Amount</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody id="bTbody">${tableRows || `<tr><td colspan="8"><div class="empty"><i class="fas fa-calendar-xmark"></i><p>No bookings yet</p></div></td></tr>`}</tbody>
      </table></div>
    </div>
  </div>`;
}

window.filterBks = function() {
  const q = ($('bSearch')?.value || '').toLowerCase();
  const f = $('bFilter')?.value || '';
  document.querySelectorAll('#bTbody tr').forEach(tr => {
    const text = tr.textContent.toLowerCase();
    const badge = tr.querySelector('.badge')?.textContent || '';
    tr.style.display = (!q || text.includes(q)) && (!f || badge === f) ? '' : 'none';
  });
};

window.viewBkModal = async (id) => {
  try {
    const b = await apiCall('GET', `/bookings/${id}`);
    showModal(`Booking #${id}`, `
      <div class="g2" style="margin-bottom:16px">
        ${[['Guest',esc(b.fullName)],['Email',esc(b.email||'—')],['Room',`#${esc(b.roomNumber)} ${esc(b.roomType)}`],['Floor',b.floor||'—'],['Check-in',fmtDate(b.checkIn)],['Check-out',fmtDate(b.checkOut)],['Nights',nights(b.checkIn,b.checkOut)],['Total',fmtMoney(b.total)],['Payment',esc(b.payment||b.paymentMethod||'—')],['Status',statusBadge(b.status)]].map(([k,v])=>`
          <div style="padding:10px;background:var(--bg3);border-radius:8px">
            <div style="font-size:10px;color:var(--text3);margin-bottom:3px">${k}</div>
            <div style="font-weight:500">${v}</div>
          </div>`).join('')}
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        ${b.status === 'Confirmed' ? `<button class="btn btn-success" onclick="hideModal();doCheckIn(${id})"><i class="fas fa-arrow-right-to-bracket"></i> Check In</button>` : ''}
        ${b.status === 'Checked In' ? `<button class="btn btn-outline" onclick="hideModal();doCheckOut(${id})"><i class="fas fa-arrow-right-from-bracket"></i> Check Out</button>` : ''}
      </div>`);
  } catch(err) { toast(err.message, 'error'); }
};

window.doCheckIn = async (id) => {
  try { await apiCall('POST', `/bookings/${id}/checkin`); toast('Guest checked in!', 'success'); go(currentPage); }
  catch(err) { toast(err.message, 'error'); }
};
window.doCheckOut = async (id) => {
  try { await apiCall('POST', `/bookings/${id}/checkout`); toast('Checked out — room now available', 'success'); go(currentPage); }
  catch(err) { toast(err.message, 'error'); }
};
window.doCancelBk = async (id) => {
  if (!confirm('Cancel this booking?')) return;
  try { await apiCall('POST', `/bookings/${id}/cancel`); toast('Booking cancelled', 'warning'); go(currentPage); }
  catch(err) { toast(err.message, 'error'); }
};

// New booking modal for admin/receptionist
window.openNewBkModal = async (preRoomId) => {
  try {
    const [customers, rooms] = await Promise.all([
      apiCall('GET', '/users'),
      apiCall('GET', '/rooms')
    ]);
    const custList = (customers || []).filter(u => (u.role||'').toLowerCase() === 'customer');
    const availRooms = (rooms || []).filter(r => r.status === 'Available');

    showModal('<i class="fas fa-calendar-plus" style="color:var(--gold)"></i> New Booking', `
      <div class="fgrid">
        <div class="fg"><label>Guest</label>
          <select id="nbUser">
            ${custList.length ? custList.map(u=>`<option value="${u.id}">${esc(u.fullName)}</option>`).join('') : '<option value="">No customers found</option>'}
          </select>
        </div>
        <div class="fg"><label>Room (Available only)</label>
          <select id="nbRoom">
            ${availRooms.length ? availRooms.map(r=>`<option value="${r.id}" data-price="${r.price}" ${preRoomId===r.id?'selected':''}>#${r.number} – ${esc(r.type)} (${fmtMoney(r.price)}/n)</option>`).join('') : '<option value="">No available rooms</option>'}
          </select>
        </div>
        <div class="fg"><label>Check-in</label><input type="date" id="nbCin" min="${today()}" value="${today()}"/></div>
        <div class="fg"><label>Check-out</label><input type="date" id="nbCout" min="${tomorrow()}" value="${tomorrow()}"/></div>
        <div class="fg full"><label>Payment Method</label><select id="nbPay"><option>Wallet</option><option>Credit Card</option><option>Cash</option></select></div>
      </div>
      <div id="nbTotal" style="text-align:center;padding:10px;background:var(--bg3);border-radius:8px;font-size:13px;color:var(--text2);margin-bottom:12px">Select dates to see total</div>
      <div class="fa-row"><button class="btn btn-outline" onclick="hideModal()">Cancel</button><button class="btn btn-primary" onclick="submitNewBk()"><i class="fas fa-check"></i> Create Booking</button></div>`);

    ['nbCin','nbCout','nbRoom'].forEach(id => $(id)?.addEventListener('change', calcNbTotal));
    calcNbTotal();
  } catch(err) { toast('Failed to load booking form: ' + err.message, 'error'); }
};

function calcNbTotal() {
  const cin = $('nbCin')?.value, cout = $('nbCout')?.value, el = $('nbTotal');
  const sel = $('nbRoom');
  if (!cin || !cout || !sel || !el) return;
  const price = parseFloat(sel.selectedOptions[0]?.dataset.price || 0);
  if (!price) { el.innerHTML = 'Select a room'; return; }
  const n = nights(cin, cout);
  if (n <= 0) { el.innerHTML = '<span style="color:var(--red)">Invalid dates</span>'; return; }
  el.innerHTML = `${n} night${n>1?'s':''} × ${fmtMoney(price)} = <strong style="color:var(--gold-light)">${fmtMoney(n*price)}</strong>`;
}

window.submitNewBk = async () => {
  const userId = +$('nbUser')?.value, roomId = +$('nbRoom')?.value;
  const checkIn = $('nbCin')?.value, checkOut = $('nbCout')?.value;
  const paymentMethod = $('nbPay')?.value;
  if (!userId || !roomId) { toast('Please select a guest and room', 'warning'); return; }
  if (!checkIn || !checkOut) { toast('Please select dates', 'warning'); return; }
  try {
    await apiCall('POST', '/bookings', { userId, roomId, checkIn, checkOut, paymentMethod });
    toast('Booking created!', 'success'); hideModal(); go('bookings');
  } catch (err) { toast(err.message, 'error'); }
};

// ── GUESTS ────────────────────────────────────────────────────────────────
async function renderGuests(container) {
  const guests = (await apiCall('GET', '/users')).filter(u => (u.role||'').toLowerCase() === 'customer');

  const tableRows = guests.map(u => `
    <tr>
      <td><div style="display:flex;align-items:center;gap:9px">${av(u.fullName,32,11)}<div><div style="font-weight:500">${esc(u.fullName)}</div><div style="font-size:11px;color:var(--text3)">@${esc(u.username)}</div></div></div></td>
      <td>${esc(u.email||'—')}</td>
      <td>${esc(u.phone||'—')}</td>
      <td style="color:var(--gold-light);font-weight:500">${fmtMoney(u.wallet)}</td>
      <td style="color:var(--text2);font-size:12px">${fmtDate(u.joined)}</td>
      <td>
        <div style="display:flex;gap:5px">
          <button class="btn btn-ghost btn-sm btn-icon" title="View bookings" onclick="viewGuestBks(${u.id},'${esc(u.fullName)}')"><i class="fas fa-calendar"></i></button>
          ${currentUser.role === 'admin' ? `<button class="btn btn-danger btn-sm btn-icon" onclick="delUser(${u.id})"><i class="fas fa-trash"></i></button>` : ''}
        </div>
      </td>
    </tr>`).join('');

  container.innerHTML = `<div class="page">
    <div class="ph">
      <div><h1>Guest Directory</h1><p>${guests.length} registered guests</p></div>
      <div class="phr">${currentUser.role === 'admin' ? `<button class="btn btn-primary" onclick="openAddGuestModal()"><i class="fas fa-user-plus"></i> Add Guest</button>` : ''}</div>
    </div>
    <div class="card">
      <div class="ch"><span class="ctitle">Guests</span><div class="srch"><i class="fas fa-search"></i><input type="text" id="gSearch" placeholder="Search…" oninput="filterGuests()"/></div></div>
      <div class="tw"><table class="dt">
        <thead><tr><th>Guest</th><th>Email</th><th>Phone</th><th>Wallet</th><th>Joined</th><th>Actions</th></tr></thead>
        <tbody id="gTbody">${tableRows || `<tr><td colspan="6"><div class="empty"><i class="fas fa-users"></i><p>No guests yet</p></div></td></tr>`}</tbody>
      </table></div>
    </div>
  </div>`;
}

window.filterGuests = function() {
  const q = ($('gSearch')?.value || '').toLowerCase();
  document.querySelectorAll('#gTbody tr').forEach(tr => { tr.style.display = !q || tr.textContent.toLowerCase().includes(q) ? '' : 'none'; });
};

window.viewGuestBks = async (uid, name) => {
  try {
    const bookings = await apiCall('GET', `/bookings?userId=${uid}`);
    showModal(`${esc(name)}'s Bookings`, bookings.length ? `
      <div class="tw"><table class="dt">
        <thead><tr><th>Room</th><th>Check-in</th><th>Check-out</th><th>Amount</th><th>Status</th></tr></thead>
        <tbody>${bookings.map(b=>`<tr><td>#${esc(b.roomNumber)} ${esc(b.roomType)}</td><td>${fmtDate(b.checkIn)}</td><td>${fmtDate(b.checkOut)}</td><td>${fmtMoney(b.total)}</td><td>${statusBadge(b.status)}</td></tr>`).join('')}</tbody>
      </table></div>` : '<div class="empty"><i class="fas fa-calendar-xmark"></i><p>No bookings yet</p></div>');
  } catch(err) { toast(err.message, 'error'); }
};

window.openAddGuestModal = () => {
  showModal('<i class="fas fa-user-plus" style="color:var(--gold)"></i> Add Guest', `
    <div class="fgrid">
      <div class="fg"><label>Full Name</label><input type="text" id="agName" placeholder="Full name"/></div>
      <div class="fg"><label>Username</label><input type="text" id="agUser" placeholder="username"/></div>
      <div class="fg"><label>Email</label><input type="email" id="agEmail" placeholder="email@example.com"/></div>
      <div class="fg"><label>Phone</label><input type="tel" id="agPhone" placeholder="+92 321…"/></div>
      <div class="fg full"><label>Password</label><input type="password" id="agPass" placeholder="Temporary password"/></div>
    </div>
    <div class="fa-row"><button class="btn btn-outline" onclick="hideModal()">Cancel</button><button class="btn btn-primary" onclick="submitAddGuest()"><i class="fas fa-check"></i> Add</button></div>`);
};

window.submitAddGuest = async () => {
  const fullName=$('agName').value, username=$('agUser').value, email=$('agEmail').value, password=$('agPass').value, phone=$('agPhone').value;
  if (!fullName||!username||!email||!password) { toast('All fields required','error'); return; }
  try {
    await apiCall('POST', '/auth/register', { fullName, username, email, password, phone });
    toast('Guest added!', 'success'); hideModal(); go('guests');
  } catch (err) { toast(err.message, 'error'); }
};

window.delUser = async (id) => {
  if (id === currentUser.id) { toast('Cannot delete yourself', 'error'); return; }
  if (!confirm('Delete this user?')) return;
  try {
    await apiCall('DELETE', `/users/${id}`);
    toast('User deleted', 'warning'); go(currentPage);
  } catch(err) { toast(err.message, 'error'); }
};

// ── PAYMENTS ──────────────────────────────────────────────────────────────
async function renderPayments(container) {
  const payments = await apiCall('GET', '/payments');

  const tableRows = (payments||[]).slice().reverse().map(p => `
    <tr>
      <td style="color:var(--text3);font-size:11px">#${p.id}</td>
      <td style="font-size:12px">#${p.bookingId}</td>
      <td>${esc(p.guestName||'—')}</td>
      <td style="font-weight:500">${fmtMoney(p.amount)}</td>
      <td>${esc(p.method)}</td>
      <td style="color:var(--text2);font-size:12px">${fmtDate(p.date)}</td>
      <td>${statusBadge(p.status)}</td>
      <td>${p.status === 'Pending' ? `<button class="btn btn-success btn-sm" onclick="markPaid(${p.id})"><i class="fas fa-check"></i> Mark Paid</button>` : ''}</td>
    </tr>`).join('');

  const collected = (payments||[]).filter(p=>p.status==='Paid').reduce((a,p)=>a+p.amount,0);
  container.innerHTML = `<div class="page">
    <div class="ph"><div><h1>Payments</h1><p>${(payments||[]).length} transactions</p></div></div>
    <div class="sg">
      ${[{l:'Paid',v:(payments||[]).filter(p=>p.status==='Paid').length,c:'green',i:'fa-circle-check'},{l:'Pending',v:(payments||[]).filter(p=>p.status==='Pending').length,c:'amber',i:'fa-clock'},{l:'Failed',v:(payments||[]).filter(p=>p.status==='Failed').length,c:'red',i:'fa-times-circle'},{l:'Total Collected',v:fmtMoney(collected),c:'gold',i:'fa-dollar-sign'}].map(s=>`
        <div class="sc ${s.c}"><div class="sico ${s.c}"><i class="fas ${s.i}"></i></div><div class="slabel">${s.l}</div><div class="sval">${s.v}</div></div>`).join('')}
    </div>
    <div class="card">
      <div class="ch"><span class="ctitle">All Transactions</span>
        <div class="sbar">
          <div class="srch"><i class="fas fa-search"></i><input type="text" id="pySearch" placeholder="Search…" oninput="filterPayments()"/></div>
          <select class="fsel" id="pyFilter" onchange="filterPayments()"><option value="">All</option><option>Pending</option><option>Paid</option><option>Failed</option></select>
        </div>
      </div>
      <div class="tw"><table class="dt">
        <thead><tr><th>ID</th><th>Booking</th><th>Guest</th><th>Amount</th><th>Method</th><th>Date</th><th>Status</th><th></th></tr></thead>
        <tbody id="pyTbody">${tableRows || `<tr><td colspan="8"><div class="empty"><i class="fas fa-receipt"></i><p>No payments yet</p></div></td></tr>`}</tbody>
      </table></div>
    </div>
  </div>`;
}

window.filterPayments = function() {
  const q = ($('pySearch')?.value || '').toLowerCase();
  const f = $('pyFilter')?.value || '';
  document.querySelectorAll('#pyTbody tr').forEach(tr => {
    const text = tr.textContent.toLowerCase();
    const badge = tr.querySelector('.badge')?.textContent || '';
    tr.style.display = (!q || text.includes(q)) && (!f || badge === f) ? '' : 'none';
  });
};

window.markPaid = async (id) => {
  try {
    await apiCall('PUT', `/payments/${id}/pay`);
    toast('Payment marked as paid!', 'success'); go('payments');
  } catch(err) { toast(err.message, 'error'); }
};

// ── REPORTS ───────────────────────────────────────────────────────────────
async function renderReports(container) {
  const reports = await apiCall('GET', '/reports');
  const rev = reports.totalRevenue || 0, bookingsCount = reports.totalBookings || 0;
  const byType = reports.revenueByType || {};
  const maxRev = Math.max(...Object.values(byType), 1);

  container.innerHTML = `<div class="page">
    <div class="ph"><div><h1>Financial Reports</h1><p>Year-to-date performance overview</p></div></div>
    <div class="sg">
      ${[{l:'Total Revenue',v:fmtMoney(rev),c:'gold',i:'fa-dollar-sign'},{l:'Total Bookings',v:bookingsCount,c:'blue',i:'fa-calendar'},{l:'Avg per Booking',v:bookingsCount?fmtMoney(rev/bookingsCount):'$0',c:'purple',i:'fa-tag'},{l:'Occupancy',v:(reports.occupancy||0)+'%',c:'green',i:'fa-door-closed'}].map(s=>`
        <div class="sc ${s.c}"><div class="sico ${s.c}"><i class="fas ${s.i}"></i></div><div class="slabel">${s.l}</div><div class="sval">${s.v}</div></div>`).join('')}
    </div>
    <div class="g2">
      <div class="card">
        <div class="ch"><span class="ctitle">Revenue by Room Type</span></div>
        <div style="display:flex;flex-direction:column;gap:10px;padding:4px 0">
          ${Object.keys(byType).length ? Object.entries(byType).map(([k,v],i)=>`
            <div style="display:flex;flex-direction:column;gap:4px">
              <div style="display:flex;justify-content:space-between;font-size:12px"><span style="color:var(--text2)">${esc(k)}</span><span style="font-weight:500">${fmtMoney(v)}</span></div>
              <div style="height:6px;background:var(--bg3);border-radius:3px;overflow:hidden"><div style="height:100%;width:${Math.round(v/maxRev*100)}%;background:var(--${ ['gold','blue','green','purple','amber','red'][i%6]});border-radius:3px"></div></div>
            </div>`).join('') : '<div class="empty"><i class="fas fa-chart-bar"></i><p>No revenue data yet</p></div>'}
        </div>
      </div>
      <div class="card">
        <div class="ch"><span class="ctitle">Booking Status Breakdown</span></div>
        <div style="display:flex;flex-direction:column;gap:10px;padding:4px 0">
          ${['Confirmed','Checked In','Completed','Cancelled'].map(s=>{
            const cnt=reports.statusCounts?.[s]||0, pct=bookingsCount?Math.round(cnt/bookingsCount*100):0;
            const c={Confirmed:'blue','Checked In':'green',Completed:'purple',Cancelled:'red'}[s];
            return `<div style="display:flex;flex-direction:column;gap:4px">
              <div style="display:flex;justify-content:space-between;font-size:12px"><span style="color:var(--text2)">${s}</span><span style="font-weight:500">${cnt}</span></div>
              <div style="height:6px;background:var(--bg3);border-radius:3px;overflow:hidden"><div style="height:100%;width:${pct}%;background:var(--${c});border-radius:3px"></div></div>
            </div>`;}).join('')}
        </div>
      </div>
    </div>
  </div>`;
}

// ── STAFF ─────────────────────────────────────────────────────────────────
async function renderStaff(container) {
  const all = await apiCall('GET', '/users');
  const staff = all.filter(u => ['admin','receptionist'].includes((u.role||'').toLowerCase()));

  const tableRows = staff.map(u => `
    <tr>
      <td><div style="display:flex;align-items:center;gap:9px">${av(u.fullName,32,11)}<span style="font-weight:500">${esc(u.fullName)}</span></div></td>
      <td style="color:var(--text2)">@${esc(u.username)}</td>
      <td>${esc(u.email||'—')}</td>
      <td>${roleBadge(u.role)}</td>
      <td style="color:var(--text2);font-size:12px">${fmtDate(u.joined)}</td>
      <td>${u.id !== currentUser.id ? `<button class="btn btn-danger btn-sm btn-icon" onclick="delUser(${u.id})"><i class="fas fa-trash"></i></button>` : '<span style="font-size:11px;color:var(--text3)">you</span>'}</td>
    </tr>`).join('');

  container.innerHTML = `<div class="page">
    <div class="ph">
      <div><h1>Staff Management</h1><p>${staff.length} staff members</p></div>
      <div class="phr"><button class="btn btn-primary" onclick="openAddStaffModal()"><i class="fas fa-user-plus"></i> Add Staff</button></div>
    </div>
    <div class="card"><div class="tw"><table class="dt">
      <thead><tr><th>Name</th><th>Username</th><th>Email</th><th>Role</th><th>Joined</th><th></th></tr></thead>
      <tbody>${tableRows || `<tr><td colspan="6"><div class="empty"><i class="fas fa-user-tie"></i><p>No staff yet</p></div></td></tr>`}</tbody>
    </table></div></div>
  </div>`;
}

window.openAddStaffModal = () => {
  showModal('<i class="fas fa-user-tie" style="color:var(--gold)"></i> Add Staff Member', `
    <div class="fgrid">
      <div class="fg"><label>Full Name</label><input type="text" id="stName" placeholder="Full name"/></div>
      <div class="fg"><label>Username</label><input type="text" id="stUser" placeholder="username"/></div>
      <div class="fg"><label>Email</label><input type="email" id="stEmail" placeholder="email"/></div>
      <div class="fg"><label>Phone</label><input type="tel" id="stPhone" placeholder="+92 321…"/></div>
      <div class="fg"><label>Role</label><select id="stRole"><option value="receptionist">Receptionist</option><option value="admin">Admin</option></select></div>
      <div class="fg"><label>Password</label><input type="password" id="stPass" placeholder="Password"/></div>
    </div>
    <div class="fa-row"><button class="btn btn-outline" onclick="hideModal()">Cancel</button><button class="btn btn-primary" onclick="submitAddStaff()"><i class="fas fa-check"></i> Add</button></div>`);
};

window.submitAddStaff = async () => {
  const fullName=$('stName').value, username=$('stUser').value, email=$('stEmail').value, role=$('stRole').value, password=$('stPass').value, phone=$('stPhone').value;
  if (!fullName||!username||!email||!password) { toast('All fields required','error'); return; }
  try {
    await apiCall('POST', '/users', { fullName, username, email, password, phone, role });
    toast('Staff added!', 'success'); hideModal(); go('staff');
  } catch (err) { toast(err.message, 'error'); }
};

// ── ADMIN COMPLAINTS ──────────────────────────────────────────────────────
async function renderAdminComplaints(container) {
  const complaints = await apiCall('GET', '/complaints');
  container.innerHTML = `<div class="page">
    <div class="ph"><div><h1>Complaints</h1><p>${(complaints||[]).length} total submissions</p></div></div>
    <div class="card">
      ${complaints.length ? `<div class="tw"><table class="dt">
        <thead><tr><th>From</th><th>Category</th><th>Message</th><th>Date</th><th>Status</th></tr></thead>
        <tbody>${complaints.map(c=>`<tr><td>${esc(c.userName||c.customerName||'—')}</td><td>${esc(c.category||c.subject||'General')}</td><td style="max-width:260px;white-space:normal;font-size:12px">${esc(c.message||c.description||'—')}</td><td style="font-size:12px;color:var(--text2)">${fmtDate(c.date)}</td><td>${statusBadge(c.status)}</td></tr>`).join('')}</tbody>
      </table></div>` : '<div class="empty"><i class="fas fa-flag"></i><p>No complaints submitted yet</p></div>'}
    </div>
  </div>`;
}

// ── CUSTOMER: MY DASHBOARD ────────────────────────────────────────────────
async function renderMyDashboard(container) {
  const myBookings = await apiCall('GET', '/bookings/my');
  const active = (myBookings||[]).filter(b => ['Confirmed','Checked In'].includes(b.status));

  container.innerHTML = `<div class="page">
    <div class="ph">
      <div><h1>Welcome back, ${esc(currentUser.fullName.split(' ')[0])}</h1><p>Your stay summary</p></div>
      <div class="phr">
        <span class="wallet-chip"><i class="fas fa-wallet"></i> ${fmtMoney(currentUser.wallet)}</span>
        <button class="btn btn-primary" onclick="go('browse')"><i class="fas fa-search"></i> Browse Rooms</button>
      </div>
    </div>
    <div class="sg">
      <div class="sc blue"><div class="sico blue"><i class="fas fa-calendar-check"></i></div><div class="slabel">Active Bookings</div><div class="sval" style="color:var(--blue)">${active.length}</div></div>
      <div class="sc gold"><div class="sico gold"><i class="fas fa-list-check"></i></div><div class="slabel">Total Bookings</div><div class="sval">${(myBookings||[]).length}</div></div>
      <div class="sc green"><div class="sico green"><i class="fas fa-star"></i></div><div class="slabel">Completed Stays</div><div class="sval" style="color:var(--green)">${(myBookings||[]).filter(b=>b.status==='Completed').length}</div></div>
      <div class="sc amber"><div class="sico amber"><i class="fas fa-wallet"></i></div><div class="slabel">Wallet Balance</div><div class="sval" style="color:var(--gold-light)">${fmtMoney(currentUser.wallet)}</div></div>
    </div>
    ${active.length ? `
      <div class="card">
        <div class="ch"><span class="ctitle">Active Reservations</span><span class="badge bdg-green">${active.length} active</span></div>
        ${active.map(b=>`
          <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 0;border-bottom:1px solid var(--border)">
            <div>
              <div style="font-weight:500">Room ${esc(b.roomNumber)} – ${esc(b.roomType)}</div>
              <div style="font-size:12px;color:var(--text2)">${fmtDate(b.checkIn)} → ${fmtDate(b.checkOut)} · ${fmtMoney(b.total)}</div>
            </div>
            <div style="display:flex;gap:8px;align-items:center">
              ${statusBadge(b.status)}
              ${b.status === 'Confirmed' ? `<button class="btn btn-danger btn-sm" onclick="custCancelBk(${b.id})">Cancel</button>` : ''}
            </div>
          </div>`).join('')}
      </div>` : `
      <div class="card">
        <div class="empty"><i class="fas fa-calendar-xmark"></i><p>No active bookings yet.</p><button class="btn btn-primary" onclick="go('browse')"><i class="fas fa-search"></i> Find a Room</button></div>
      </div>`}
  </div>`;
}

window.custCancelBk = async (id) => {
  if (!confirm('Cancel booking? You will receive an 80% wallet refund.')) return;
  try {
    await apiCall('POST', `/bookings/${id}/cancel`);
    toast('Booking cancelled. Refund added to wallet.', 'warning');
    go('my-bookings');
  } catch(err) { toast(err.message, 'error'); }
};

// ── CUSTOMER: BROWSE ROOMS ────────────────────────────────────────────────
async function renderBrowseRooms(container) {
  const rooms = await apiCall('GET', '/rooms');
  const available = rooms.filter(r => r.status === 'Available');
  const emojis = { Standard:'🛏️', 'Deluxe King':'👑', 'Deluxe Twin':'🛏', Suite:'🛋️', Penthouse:'🏙️' };

  container.innerHTML = `<div class="page">
    <div class="ph"><div><h1>Browse Rooms</h1><p>${available.length} rooms available</p></div></div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:14px">
      ${available.length ? available.map(r=>`
        <div class="rcard">
          <div class="rcard-img">${emojis[r.type]||'🛏️'}</div>
          <div class="rcard-body">
            <div class="rcard-name">Room #${esc(r.number)}</div>
            <div class="rcard-sub">${esc(r.type)} · Floor ${r.floor}<br><span style="font-size:11px;color:var(--text3)">${esc(r.amenities||'—')}</span></div>
            <div style="display:flex;align-items:center;justify-content:space-between;margin-top:10px">
              <div class="rcard-price">${fmtMoney(r.price)}<span>/night</span></div>
              <button class="btn btn-primary btn-sm" onclick="openCustBkModal(${r.id})"><i class="fas fa-calendar-plus"></i> Book</button>
            </div>
          </div>
        </div>`).join('') : '<div class="empty" style="grid-column:1/-1"><i class="fas fa-door-open"></i><p>No rooms available right now. Please check back later.</p></div>'}
    </div>
  </div>`;
}

// ── CUSTOMER: BOOK MODAL ──────────────────────────────────────────────────
window.openCustBkModal = async (roomId) => {
  try {
    const room = await apiCall('GET', `/rooms/${roomId}`);
    showModal(`<i class="fas fa-calendar-plus" style="color:var(--gold)"></i> Book Room #${room.number}`, `
      <div style="background:var(--bg3);border-radius:8px;padding:12px;margin-bottom:14px;display:flex;justify-content:space-between;align-items:center">
        <span style="color:var(--text2)">${esc(room.type)} · Floor ${room.floor}</span>
        <span style="font-weight:600;color:var(--gold-light)">${fmtMoney(room.price)}/night</span>
      </div>
      <div class="fgrid">
        <div class="fg"><label>Check-in Date</label><input type="date" id="cbCin" min="${today()}" value="${today()}"/></div>
        <div class="fg"><label>Check-out Date</label><input type="date" id="cbCout" min="${tomorrow()}" value="${tomorrow()}"/></div>
      </div>
      <div id="cbTotal" style="text-align:center;padding:12px;background:var(--bg3);border-radius:8px;font-size:13px;color:var(--text2);margin:12px 0">
        1 night × ${fmtMoney(room.price)} = <strong style="color:var(--gold-light)">${fmtMoney(room.price)}</strong>
      </div>
      <div class="info-block" style="margin-bottom:14px">
        <i class="fas fa-wallet"></i>
        <span>Your wallet balance: <strong style="color:var(--gold-light)">${fmtMoney(currentUser.wallet)}</strong></span>
      </div>
      <div class="fa-row">
        <button class="btn btn-outline" onclick="hideModal()">Cancel</button>
        <button class="btn btn-primary" onclick="confirmCustBooking(${roomId}, ${room.price})"><i class="fas fa-check"></i> Confirm Booking</button>
      </div>`);

    ['cbCin','cbCout'].forEach(id => $(id)?.addEventListener('change', () => calcCustTotal(room.price)));
  } catch(err) { toast('Failed to load room: ' + err.message, 'error'); }
};

function calcCustTotal(price) {
  const cin = $('cbCin')?.value, cout = $('cbCout')?.value, el = $('cbTotal');
  if (!cin || !cout || !el) return;
  const n = nights(cin, cout);
  if (n <= 0) { el.innerHTML = '<span style="color:var(--red)">Check-out must be after check-in</span>'; return; }
  el.innerHTML = `${n} night${n>1?'s':''} × ${fmtMoney(price)} = <strong style="color:var(--gold-light)">${fmtMoney(n*price)}</strong>`;
}

window.confirmCustBooking = async (roomId, price) => {
  const cin = $('cbCin')?.value, cout = $('cbCout')?.value;
  if (!cin || !cout) { toast('Please select dates', 'warning'); return; }
  const n = nights(cin, cout);
  if (n <= 0) { toast('Check-out must be after check-in', 'error'); return; }
  const total = n * price;
  if (currentUser.wallet < total) {
    toast(`Insufficient balance. Need ${fmtMoney(total)}, have ${fmtMoney(currentUser.wallet)}. Top up your wallet first.`, 'error');
    return;
  }
  try {
    await apiCall('POST', '/bookings', { roomId, checkIn: cin, checkOut: cout, paymentMethod: 'Wallet' });
    currentUser.wallet = currentUser.wallet - total; // optimistic update
    buildSidebar(); // refresh wallet display
    toast(`Room booked! ${fmtMoney(total)} deducted from wallet.`, 'success');
    hideModal();
    go('my-bookings');
  } catch (err) { toast(err.message, 'error'); }
};

// ── CUSTOMER: MY BOOKINGS ─────────────────────────────────────────────────
async function renderMyBookings(container) {
  const bookings = await apiCall('GET', '/bookings/my');

  const tableRows = (bookings||[]).slice().reverse().map(b => `
    <tr>
      <td><span style="font-weight:500">#${esc(b.roomNumber)}</span> <span style="color:var(--text3);font-size:11px">· ${esc(b.roomType)}</span></td>
      <td>${fmtDate(b.checkIn)}</td>
      <td>${fmtDate(b.checkOut)}</td>
      <td>${nights(b.checkIn,b.checkOut)}</td>
      <td style="font-weight:500">${fmtMoney(b.total)}</td>
      <td style="color:var(--text2);font-size:11px">${fmtDate(b.date)}</td>
      <td>${statusBadge(b.status)}</td>
      <td>${b.status === 'Confirmed' ? `<button class="btn btn-danger btn-sm" onclick="custCancelBk(${b.id})">Cancel</button>` : ''}</td>
    </tr>`).join('');

  container.innerHTML = `<div class="page">
    <div class="ph"><div><h1>My Bookings</h1><p>${(bookings||[]).length} reservations</p></div></div>
    <div class="card"><div class="tw"><table class="dt">
      <thead><tr><th>Room</th><th>Check-in</th><th>Check-out</th><th>Nights</th><th>Amount</th><th>Booked</th><th>Status</th><th></th></tr></thead>
      <tbody>
        ${tableRows || `<tr><td colspan="8"><div class="empty"><i class="fas fa-calendar-xmark"></i><p>No bookings yet</p><button class="btn btn-primary" onclick="go('browse')">Browse Rooms</button></div></td></tr>`}
      </tbody>
    </table></div></div>
  </div>`;
}

// ── WALLET ────────────────────────────────────────────────────────────────
async function renderWallet(container) {
  // Refresh wallet balance from server
  try {
    const me = await apiCall('GET', '/auth/me');
    currentUser.wallet = me.wallet || 0;
    buildSidebar();
  } catch(e) { /* use cached value */ }

  container.innerHTML = `<div class="page" style="max-width:680px">
    <div class="ph"><div><h1>My Wallet</h1></div></div>
    <div class="card" style="text-align:center;padding:28px">
      <div class="sico gold" style="margin:0 auto 14px;width:48px;height:48px;font-size:22px"><i class="fas fa-wallet"></i></div>
      <div style="font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:.07em;margin-bottom:6px">Available Balance</div>
      <div style="font-size:38px;font-weight:700;color:var(--gold-light)">${fmtMoney(currentUser.wallet)}</div>
    </div>
    <div class="card">
      <div class="ch"><span class="ctitle">Add Funds</span></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px">
        ${[50,100,200,500].map(a=>`<button class="btn btn-outline" onclick="setTopupAmount(${a})">+$${a}</button>`).join('')}
      </div>
      <div style="display:flex;gap:8px">
        <div class="fg" style="flex:1;margin-bottom:0"><input type="number" id="topupAmt" placeholder="Custom amount ($)" min="1" step="1"/></div>
        <button class="btn btn-primary" onclick="doTopup()"><i class="fas fa-plus"></i> Add Funds</button>
      </div>
    </div>
    <div class="card">
      <div class="ch"><span class="ctitle">Transaction History</span></div>
      <div class="tw"><table class="dt">
        <thead><tr><th>Booking</th><th>Amount</th><th>Method</th><th>Date</th><th>Status</th></tr></thead>
        <tbody id="txnBody"><tr><td colspan="5"><div class="spin"></div></td></tr></tbody>
      </table></div>
    </div>
  </div>`;

  try {
    const transactions = await apiCall('GET', '/payments/my');
    $('txnBody').innerHTML = transactions.length
      ? transactions.map(p=>`<tr><td>#${p.bookingId}</td><td style="font-weight:500">${fmtMoney(p.amount)}</td><td>${esc(p.method)}</td><td style="color:var(--text2);font-size:12px">${fmtDate(p.date)}</td><td>${statusBadge(p.status)}</td></tr>`).join('')
      : '<tr><td colspan="5"><div class="empty"><i class="fas fa-receipt"></i><p>No transactions yet</p></div></td></tr>';
  } catch(err) {
    $('txnBody').innerHTML = '<tr><td colspan="5"><div class="empty">Failed to load transactions</div></td></tr>';
  }
}

window.setTopupAmount = (a) => { const el = $('topupAmt'); if(el) el.value = a; };
window.doTopup = async () => {
  const amount = parseFloat($('topupAmt')?.value || 0);
  if (amount <= 0) { toast('Enter a valid amount', 'error'); return; }
  try {
    const result = await apiCall('POST', '/wallet/topup', { amount });
    currentUser.wallet = result.newBalance;
    buildSidebar();
    toast(`${fmtMoney(amount)} added to wallet!`, 'success');
    go('wallet');
  } catch (err) { toast(err.message, 'error'); }
};

// ── PROFILE ───────────────────────────────────────────────────────────────
async function renderProfile(container) {
  container.innerHTML = `<div class="page" style="max-width:600px">
    <div class="ph"><div><h1>My Profile</h1></div></div>
    <div class="card">
      <div style="display:flex;align-items:center;gap:16px;margin-bottom:22px;padding-bottom:18px;border-bottom:1px solid var(--border)">
        ${av(currentUser.fullName,60,20)}
        <div>
          <div style="font-size:19px;font-weight:600">${esc(currentUser.fullName)}</div>
          <div style="color:var(--text2);font-size:13px;margin-top:3px">@${esc(currentUser.username)} · ${roleBadge(currentUser.role)}</div>
        </div>
      </div>
      <div class="fgrid">
        <div class="fg"><label>Full Name</label><input type="text" id="prName" value="${esc(currentUser.fullName)}"/></div>
        <div class="fg"><label>Email</label><input type="email" id="prEmail" value="${esc(currentUser.email||'')}"/></div>
        <div class="fg"><label>Phone</label><input type="tel" id="prPhone" value="${esc(currentUser.phone||'')}"/></div>
        <div class="fg"><label>New Password</label><input type="password" id="prPass" placeholder="Leave blank to keep current"/></div>
      </div>
      <div class="fa-row"><button class="btn btn-primary" onclick="saveProfile()"><i class="fas fa-save"></i> Save Changes</button></div>
    </div>
  </div>`;
}

window.saveProfile = async () => {
  const fullName=$('prName').value, email=$('prEmail').value, phone=$('prPhone').value, password=$('prPass').value;
  if (!fullName||!email) { toast('Name and email required','error'); return; }
  const body = { fullName, email, phone };
  if (password) body.password = password;
  try {
    await apiCall('PUT', '/users/me', body);
    currentUser.fullName = fullName;
    currentUser.email = email;
    buildSidebar();
    toast('Profile updated!', 'success');
    go('profile');
  } catch(err) { toast(err.message, 'error'); }
};

// ── COMPLAINTS (customer) ─────────────────────────────────────────────────
async function renderComplaints(container) {
  container.innerHTML = `<div class="page" style="max-width:680px">
    <div class="ph"><div><h1>Complaints & Suggestions</h1></div></div>
    <div class="card">
      <div class="ch"><span class="ctitle">Submit New</span></div>
      <div class="fg"><label>Category</label><select id="cmpCat"><option>Room Issue</option><option>Service</option><option>Billing</option><option>Suggestion</option><option>Other</option></select></div>
      <div class="fg"><label>Message</label><textarea id="cmpMsg" rows="3" placeholder="Describe your issue or suggestion…"></textarea></div>
      <div class="fa-row"><button class="btn btn-primary" onclick="submitComplaint()"><i class="fas fa-paper-plane"></i> Submit</button></div>
    </div>
    <div id="myComplaintsContainer"><div class="card"><div class="spin"></div></div></div>
  </div>`;

  try {
    const myComplaints = await apiCall('GET', '/complaints/my');
    const c2 = $('myComplaintsContainer');
    if (myComplaints.length) {
      c2.innerHTML = `<div class="card"><div class="ch"><span class="ctitle">Your Submissions</span></div>
        ${myComplaints.map(c=>`
          <div style="padding:12px 0;border-bottom:1px solid var(--border)">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
              <span style="font-weight:500;font-size:13px">${esc(c.category||c.subject||'General')}</span>${statusBadge(c.status)}
            </div>
            <div style="font-size:13px;color:var(--text2)">${esc(c.message||c.description||'')}</div>
            <div style="font-size:11px;color:var(--text3);margin-top:3px">${fmtDate(c.date)}</div>
          </div>`).join('')}
      </div>`;
    } else {
      c2.innerHTML = '<div class="card"><div class="empty"><i class="fas fa-flag"></i><p>No complaints submitted yet.</p></div></div>';
    }
  } catch(err) {
    $('myComplaintsContainer').innerHTML = '<div class="card"><div class="empty">Failed to load complaints.</div></div>';
  }
}

window.submitComplaint = async () => {
  const message = $('cmpMsg')?.value.trim(), category = $('cmpCat')?.value;
  if (!message) { toast('Please write a message', 'warning'); return; }
  try {
    await apiCall('POST', '/complaints', { message, category });
    toast('Complaint submitted!', 'success');
    go('complaints');
  } catch (err) { toast(err.message, 'error'); }
};

// ── NOTIFICATIONS ─────────────────────────────────────────────────────────
async function renderNotifications(container) {
  container.innerHTML = `<div class="page" style="max-width:680px">
    <div class="ph">
      <div><h1>Notifications</h1><p id="notifCount">Loading…</p></div>
      <div class="phr"><button class="btn btn-outline btn-sm" onclick="clearAllNotifs()"><i class="fas fa-trash"></i> Clear All</button></div>
    </div>
    <div id="notifList" class="card"><div class="spin"></div></div>
  </div>`;

  try {
    const notifs = await apiCall('GET', '/notifications');
    const notifDiv = $('notifList');
    $('notifCount').textContent = `${notifs.length} message${notifs.length !== 1 ? 's' : ''}`;
    if (notifs.length) {
      notifDiv.innerHTML = notifs.slice().reverse().map(n=>`
        <div style="display:flex;gap:12px;padding:12px 0;border-bottom:1px solid var(--border)">
          <div class="sico blue" style="width:32px;height:32px;font-size:13px;flex-shrink:0"><i class="fas fa-bell"></i></div>
          <div>
            <div style="font-size:13px;font-weight:500">${esc(n.message)}</div>
            <div style="font-size:11px;color:var(--text3);margin-top:3px">${fmtDate(n.date)}</div>
          </div>
        </div>`).join('');
    } else {
      notifDiv.innerHTML = '<div class="empty"><i class="fas fa-bell-slash"></i><p>No notifications yet</p></div>';
    }
  } catch(err) {
    $('notifList').innerHTML = '<div class="empty"><i class="fas fa-exclamation-triangle"></i><p>Failed to load notifications</p></div>';
  }
}

window.clearAllNotifs = async () => {
  try {
    await apiCall('DELETE', '/notifications');
    toast('Notifications cleared', 'info');
    go('notifs');
  } catch(err) { toast(err.message, 'error'); }
};

// ── FAQS ──────────────────────────────────────────────────────────────────
function renderFaqs(container) {
  const faqs = [
    ['How do I book a room?', 'Go to Browse Rooms, pick your preferred room, select check-in and check-out dates, then confirm with your wallet balance.'],
    ['How does cancellation work?', 'You can cancel any Confirmed booking. You will receive an 80% refund to your wallet instantly.'],
    ['What are check-in and check-out times?', 'Standard check-in is 2:00 PM and check-out is 12:00 PM (noon).'],
    ['How do I add funds to my wallet?', 'Go to the Wallet section in the sidebar and use the top-up options.'],
    ['Can I modify a booking?', 'Currently bookings cannot be modified online. Please cancel and rebook if needed, or contact us directly.'],
    ['What amenities are included?', 'All rooms include complimentary WiFi. Additional amenities are listed on each room\'s detail card.']
  ];
  container.innerHTML = `<div class="page" style="max-width:720px">
    <div class="ph"><div><h1>FAQs</h1><p>Frequently asked questions</p></div></div>
    ${faqs.map(([q,a])=>`
      <div class="card" style="margin-bottom:10px">
        <div style="font-weight:600;font-size:14px;margin-bottom:7px;color:var(--gold-light)"><i class="fas fa-circle-question" style="margin-right:8px"></i>${esc(q)}</div>
        <div style="font-size:13px;color:var(--text2)">${esc(a)}</div>
      </div>`).join('')}
  </div>`;
}

// ── CONTACT ───────────────────────────────────────────────────────────────
function renderContact(container) {
  container.innerHTML = `<div class="page" style="max-width:680px">
    <div class="ph"><div><h1>Contact Us</h1><p>We're here to help 24/7</p></div></div>
    <div class="g2">
      ${[{i:'fa-phone',t:'Phone',v:'+92 321 123 4567',s:'Mon–Sun 8am–10pm',c:'green'},{i:'fa-envelope',t:'Email',v:'care@aurumhotel.com',s:'Reply within 2h',c:'blue'},{i:'fa-location-dot',t:'Address',v:'Sahiwal, Multan Road',s:'Punjab, Pakistan',c:'amber'},{i:'fa-headset',t:'Live Chat',v:'Available in-app',s:'Instant response',c:'purple'}].map(x=>`
        <div class="card">
          <div class="sico ${x.c}" style="margin-bottom:10px"><i class="fas ${x.i}"></i></div>
          <div style="font-weight:500;font-size:13px;margin-bottom:3px">${x.t}</div>
          <div style="font-size:14px;font-weight:600">${esc(x.v)}</div>
          <div style="font-size:11px;color:var(--text3)">${x.s}</div>
        </div>`).join('')}
    </div>
    <div class="card">
      <div class="ch"><span class="ctitle">Send a Message</span></div>
      <div class="fgrid">
        <div class="fg"><label>Subject</label><input type="text" id="ctSubj" placeholder="How can we help?"/></div>
        <div class="fg"><label>Email</label><input type="email" id="ctEmail" value="${esc(currentUser.email||'')}"/></div>
        <div class="fg full"><label>Message</label><textarea id="ctMsg" rows="3" placeholder="Describe your issue…"></textarea></div>
      </div>
      <div class="fa-row"><button class="btn btn-primary" onclick="sendContactMessage()"><i class="fas fa-paper-plane"></i> Send Message</button></div>
    </div>
  </div>`;
}

window.sendContactMessage = () => {
  const subject = $('ctSubj')?.value, message = $('ctMsg')?.value;
  if (!subject || !message) { toast('Please fill in subject and message', 'warning'); return; }
  toast("Message sent! We'll reply shortly.", 'success');
  $('ctSubj').value = ''; $('ctMsg').value = '';
};

// ── ENTER APP ─────────────────────────────────────────────────────────────
function enterApp() {
  if (!currentUser || !currentUser.role) { logout(); return; }
  $('authWrap').style.display = 'none';
  $('app').style.display = 'flex';
  buildSidebar();
  const defaultPage = currentUser.role === 'customer' ? 'my-dash' : 'dashboard';
  go(defaultPage);
}

// Auto-login
(async () => {
  if (authToken) {
    try {
      const user = await apiCall('GET', '/auth/me');
      if (user && user.role) {
        currentUser = { ...user, role: user.role.toLowerCase() };
        enterApp();
      } else throw new Error('Invalid user data');
    } catch(e) {
      console.error('Auto-login failed:', e);
      localStorage.removeItem('token'); authToken = null; currentUser = null;
    }
  }
})();

// Event listeners
$('tabL').onclick = () => switchTab('login');
$('tabS').onclick = () => switchTab('signup');
$('fLogin').onsubmit = doLogin;
$('fSignup').onsubmit = doSignup;
$('logoutBtn').onclick = logout;
$('mobileMenuBtn').onclick = openSb;
$('sbOv').onclick = closeSb;
$('themeToggle').onclick = toggleTheme;
$('themeToggleTop').onclick = toggleTheme;
document.querySelectorAll('.demo-chip').forEach(btn => btn.addEventListener('click', () => {
  const [u, p] = btn.dataset.demo.split(','); fillDemo(u, p);
}));

window.toggleTheme = function() {
  const cur = document.documentElement.getAttribute('data-theme');
  const next = cur === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('aurum_theme', next);
};
window.initTheme = function() {
  const t = localStorage.getItem('aurum_theme') || 'dark';
  document.documentElement.setAttribute('data-theme', t);
};
initTheme();
