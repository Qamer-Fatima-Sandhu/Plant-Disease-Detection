const express = require('express');
const cors = require('cors');
const sql = require('mssql');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const dbConfig = {
    server: process.env.DB_SERVER || 'localhost',
    database: process.env.DB_NAME || 'HotelManagementSystem',
    user: process.env.DB_USER || 'HotelUser',
    password: process.env.DB_PASSWORD || 'Pass@1234',
    options: { encrypt: false, trustServerCertificate: true }
};

let pool;
async function getPool() {
    if (!pool) { pool = await sql.connect(dbConfig); console.log('DB connected'); }
    return pool;
}

// ── AUTH MIDDLEWARE ──────────────────────────────────────────────────────
const auth = async (req, res, next) => {
    const token = (req.headers['authorization'] || '').split(' ')[1];
    if (!token) return res.status(401).json({ message: 'Access token required' });
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'secretkey');
        req.userId = decoded.userId;
        req.userRole = decoded.role;
        const pool = await getPool();
        const result = await pool.request()
            .input('userId', sql.Int, req.userId)
            .query(`
                SELECT u.UserID, u.Username, r.RoleName, c.FullName, c.WalletBalance, c.Email, c.Phone
                FROM UserAccount u
                JOIN Role r ON u.RoleID = r.RoleID
                LEFT JOIN Customer c ON u.UserID = c.UserID
                WHERE u.UserID = @userId AND u.IsActive = 1
            `);
        if (!result.recordset.length) return res.status(401).json({ message: 'User not found' });
        req.user = result.recordset[0];
        next();
    } catch(err) {
        return res.status(403).json({ message: 'Invalid or expired token' });
    }
};

const adminOnly = (req, res, next) => {
    if (req.user.RoleName.toLowerCase() !== 'admin') return res.status(403).json({ message: 'Admin access required' });
    next();
};
const staffOnly = (req, res, next) => {
    const role = req.user.RoleName.toLowerCase();
    if (!['admin','receptionist'].includes(role)) return res.status(403).json({ message: 'Staff access required' });
    next();
};

// ── AUTH ROUTES ──────────────────────────────────────────────────────────
app.post('/api/auth/login', async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ message: 'Username and password required' });
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('username', sql.VarChar, username)
            .query(`
                SELECT u.UserID, u.Username, u.PasswordHash, r.RoleName, c.FullName, c.WalletBalance
                FROM UserAccount u
                JOIN Role r ON u.RoleID = r.RoleID
                LEFT JOIN Customer c ON u.UserID = c.UserID
                WHERE u.Username = @username AND u.IsActive = 1
            `);
        if (!result.recordset.length) return res.status(401).json({ message: 'Invalid credentials' });
        const user = result.recordset[0];
        if (password !== user.PasswordHash) return res.status(401).json({ message: 'Invalid credentials' });
        const token = jwt.sign({ userId: user.UserID, role: user.RoleName }, process.env.JWT_SECRET || 'secretkey', { expiresIn: '7d' });
        res.json({
            success: true, token,
            user: { id: user.UserID, username: user.Username, role: user.RoleName.toLowerCase(), fullName: user.FullName || user.Username, wallet: user.WalletBalance || 0 }
        });
    } catch(err) { console.error(err); res.status(500).json({ message: 'Server error: ' + err.message }); }
});

app.post('/api/auth/register', async (req, res) => {
    const { fullName, username, email, password, phone } = req.body;
    if (!fullName || !username || !email || !password) return res.status(400).json({ message: 'All fields required' });
    try {
        const pool = await getPool();
        const exists = await pool.request().input('username', sql.VarChar, username).query('SELECT UserID FROM UserAccount WHERE Username = @username');
        if (exists.recordset.length) return res.status(400).json({ message: 'Username already taken' });
        const insertUser = await pool.request()
            .input('username', sql.VarChar, username)
            .input('password', sql.VarChar, password)
            .input('roleId', sql.Int, 3)
            .query(`INSERT INTO UserAccount (RoleID, Username, PasswordHash, IsActive) VALUES (@roleId, @username, @password, 1); SELECT SCOPE_IDENTITY() AS UserID`);
        const userId = insertUser.recordset[0].UserID;
        await pool.request()
            .input('userId', sql.Int, userId)
            .input('fullName', sql.NVarChar, fullName)
            .input('email', sql.VarChar, email)
            .input('phone', sql.VarChar, phone || '')
            .query(`INSERT INTO Customer (UserID, FullName, Email, Phone, WalletBalance) VALUES (@userId, @fullName, @email, @phone, 0)`);
        res.json({ success: true, message: 'Account created successfully' });
    } catch(err) { console.error(err); res.status(500).json({ message: 'Registration failed: ' + err.message }); }
});

app.get('/api/auth/me', auth, (req, res) => {
    res.json({
        id: req.user.UserID, username: req.user.Username,
        role: req.user.RoleName.toLowerCase(),
        fullName: req.user.FullName || req.user.Username,
        wallet: req.user.WalletBalance || 0,
        email: req.user.Email || '',
        phone: req.user.Phone || ''
    });
});

// ── ROOMS ROUTES ─────────────────────────────────────────────────────────
app.get('/api/rooms', auth, async (req, res) => {
    try {
        const pool = await getPool();
        // optional status filter
        const statusFilter = req.query.status ? `WHERE r.Status = '${req.query.status}'` : '';
        const result = await pool.request().query(`
            SELECT r.RoomID as id, r.RoomNumber as number, rt.TypeName as type,
                   r.FloorNumber as floor, rt.PricePerNight as price,
                   r.Status as status, r.Description as amenities
            FROM Room r
            JOIN RoomType rt ON r.RoomTypeID = rt.RoomTypeID
            ${statusFilter}
            ORDER BY r.FloorNumber, r.RoomNumber
        `);
        res.json(result.recordset);
    } catch(err) { res.status(500).json({ message: err.message }); }
});

app.get('/api/rooms/stats', auth, async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query(`
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN Status='Occupied' THEN 1 ELSE 0 END) as occupied,
                SUM(CASE WHEN Status='Available' THEN 1 ELSE 0 END) as available,
                SUM(CASE WHEN Status='Maintenance' THEN 1 ELSE 0 END) as maintenance
            FROM Room
        `);
        res.json(result.recordset[0]);
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// GET single room — must come AFTER /api/rooms/stats
app.get('/api/rooms/:id', auth, async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', sql.Int, req.params.id)
            .query(`
                SELECT r.RoomID as id, r.RoomNumber as number, rt.TypeName as type,
                       r.FloorNumber as floor, rt.PricePerNight as price,
                       r.Status as status, r.Description as amenities
                FROM Room r
                JOIN RoomType rt ON r.RoomTypeID = rt.RoomTypeID
                WHERE r.RoomID = @id
            `);
        if (!result.recordset.length) return res.status(404).json({ message: 'Room not found' });
        res.json(result.recordset[0]);
    } catch(err) { res.status(500).json({ message: err.message }); }
});

app.post('/api/rooms', auth, staffOnly, async (req, res) => {
    const { number, floor, type, price, amenities } = req.body;
    if (!number || !price) return res.status(400).json({ message: 'Number and price required' });
    try {
        const pool = await getPool();
        // Find or create RoomType
        let typeRes = await pool.request().input('type', sql.NVarChar, type).query('SELECT RoomTypeID FROM RoomType WHERE TypeName = @type');
        let typeId;
        if (typeRes.recordset.length) {
            typeId = typeRes.recordset[0].RoomTypeID;
        } else {
            const ins = await pool.request().input('type', sql.NVarChar, type).input('price', sql.Decimal(12,2), price)
                .query(`INSERT INTO RoomType (TypeName, PricePerNight) VALUES (@type, @price); SELECT SCOPE_IDENTITY() AS id`);
            typeId = ins.recordset[0].id;
        }
        await pool.request()
            .input('number', sql.VarChar, String(number))
            .input('floor', sql.Int, floor || 1)
            .input('typeId', sql.Int, typeId)
            .input('desc', sql.NVarChar, amenities || '')
            .query(`INSERT INTO Room (RoomNumber, FloorNumber, RoomTypeID, Status, Description) VALUES (@number, @floor, @typeId, 'Available', @desc)`);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ message: err.message }); }
});

app.put('/api/rooms/:id', auth, staffOnly, async (req, res) => {
    const { type, price, status, floor, amenities } = req.body;
    try {
        const pool = await getPool();
        let typeRes = await pool.request().input('type', sql.NVarChar, type).query('SELECT RoomTypeID FROM RoomType WHERE TypeName = @type');
        let typeId;
        if (typeRes.recordset.length) {
            typeId = typeRes.recordset[0].RoomTypeID;
            await pool.request().input('typeId', sql.Int, typeId).input('price', sql.Decimal(12,2), price)
                .query('UPDATE RoomType SET PricePerNight = @price WHERE RoomTypeID = @typeId');
        } else {
            const ins = await pool.request().input('type', sql.NVarChar, type).input('price', sql.Decimal(12,2), price)
                .query(`INSERT INTO RoomType (TypeName, PricePerNight) VALUES (@type, @price); SELECT SCOPE_IDENTITY() AS id`);
            typeId = ins.recordset[0].id;
        }
        await pool.request()
            .input('id', sql.Int, req.params.id)
            .input('typeId', sql.Int, typeId)
            .input('status', sql.VarChar, status)
            .input('floor', sql.Int, floor)
            .input('desc', sql.NVarChar, amenities || '')
            .query(`UPDATE Room SET RoomTypeID=@typeId, Status=@status, FloorNumber=@floor, Description=@desc WHERE RoomID=@id`);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ message: err.message }); }
});

app.delete('/api/rooms/:id', auth, adminOnly, async (req, res) => {
    try {
        const pool = await getPool();
        await pool.request().input('id', sql.Int, req.params.id).query('DELETE FROM Room WHERE RoomID = @id');
        res.json({ success: true });
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// ── BOOKINGS ROUTES ──────────────────────────────────────────────────────
// GET all bookings (staff) — supports ?userId filter
app.get('/api/bookings', auth, async (req, res) => {
    try {
        const pool = await getPool();
        const userFilter = req.query.userId ? `AND c.UserID = ${parseInt(req.query.userId)}` : '';
        const result = await pool.request().query(`
            SELECT r.ReservationID as id, r.CheckInDate as checkIn, r.CheckOutDate as checkOut,
                   r.Status as status, r.TotalAmount as total, r.BookingDate as date,
                   r.PaymentMethod as payment,
                   ro.RoomNumber as roomNumber, rt.TypeName as roomType, ro.FloorNumber as floor,
                   c.FullName as fullName, c.Email as email, c.UserID as userId
            FROM Reservation r
            JOIN Customer c ON r.CustomerID = c.CustomerID
            JOIN Room ro ON r.RoomID = ro.RoomID
            JOIN RoomType rt ON ro.RoomTypeID = rt.RoomTypeID
            WHERE 1=1 ${userFilter}
            ORDER BY r.BookingDate DESC
        `);
        res.json(result.recordset);
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// GET my bookings (customer)
app.get('/api/bookings/my', auth, async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('userId', sql.Int, req.userId)
            .query(`
                SELECT r.ReservationID as id, r.CheckInDate as checkIn, r.CheckOutDate as checkOut,
                       r.Status as status, r.TotalAmount as total, r.BookingDate as date,
                       ro.RoomNumber as roomNumber, rt.TypeName as roomType
                FROM Reservation r
                JOIN Customer c ON r.CustomerID = c.CustomerID
                JOIN Room ro ON r.RoomID = ro.RoomID
                JOIN RoomType rt ON ro.RoomTypeID = rt.RoomTypeID
                WHERE c.UserID = @userId
                ORDER BY r.BookingDate DESC
            `);
        res.json(result.recordset);
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// GET recent bookings for dashboard
app.get('/api/bookings/recent', auth, async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query(`
            SELECT TOP 6 r.ReservationID as id, r.CheckInDate as checkIn, r.CheckOutDate as checkOut,
                   r.Status as status, r.TotalAmount as total,
                   ro.RoomNumber as roomNumber, rt.TypeName as roomType,
                   c.FullName as fullName
            FROM Reservation r
            JOIN Customer c ON r.CustomerID = c.CustomerID
            JOIN Room ro ON r.RoomID = ro.RoomID
            JOIN RoomType rt ON ro.RoomTypeID = rt.RoomTypeID
            ORDER BY r.BookingDate DESC
        `);
        res.json(result.recordset);
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// GET single booking
app.get('/api/bookings/:id', auth, async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request()
            .input('id', sql.Int, req.params.id)
            .query(`
                SELECT r.ReservationID as id, r.CheckInDate as checkIn, r.CheckOutDate as checkOut,
                       r.Status as status, r.TotalAmount as total, r.BookingDate as date,
                       r.PaymentMethod as payment,
                       ro.RoomNumber as roomNumber, rt.TypeName as roomType, ro.FloorNumber as floor,
                       c.FullName as fullName, c.Email as email
                FROM Reservation r
                JOIN Customer c ON r.CustomerID = c.CustomerID
                JOIN Room ro ON r.RoomID = ro.RoomID
                JOIN RoomType rt ON ro.RoomTypeID = rt.RoomTypeID
                WHERE r.ReservationID = @id
            `);
        if (!result.recordset.length) return res.status(404).json({ message: 'Booking not found' });
        res.json(result.recordset[0]);
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// POST create booking
app.post('/api/bookings', auth, async (req, res) => {
    // userId can be provided by staff, or derived from token for customers
    const { roomId, checkIn, checkOut, paymentMethod, userId: bodyUserId } = req.body;
    if (!roomId || !checkIn || !checkOut) return res.status(400).json({ message: 'Room, check-in and check-out required' });
    try {
        const pool = await getPool();
        // Determine which user the booking is for
        const targetUserId = bodyUserId || req.userId;
        const custRes = await pool.request().input('userId', sql.Int, targetUserId)
            .query('SELECT CustomerID, WalletBalance FROM Customer WHERE UserID = @userId');
        if (!custRes.recordset.length) return res.status(400).json({ message: 'Customer not found' });
        const customer = custRes.recordset[0];

        const roomRes = await pool.request().input('roomId', sql.Int, roomId)
            .query(`SELECT rt.PricePerNight, r.Status FROM Room r JOIN RoomType rt ON r.RoomTypeID = rt.RoomTypeID WHERE r.RoomID = @roomId`);
        if (!roomRes.recordset.length) return res.status(404).json({ message: 'Room not found' });
        const room = roomRes.recordset[0];
        if (room.Status !== 'Available') return res.status(400).json({ message: 'Room is not available' });

        const n = Math.max(1, Math.round((new Date(checkOut) - new Date(checkIn)) / 86400000));
        const total = n * room.PricePerNight;
        const method = paymentMethod || 'Wallet';

        // Deduct wallet if payment method is Wallet
        if (method === 'Wallet') {
            if (customer.WalletBalance < total) return res.status(400).json({ message: `Insufficient wallet balance. Need $${total.toFixed(2)}, have $${customer.WalletBalance.toFixed(2)}` });
            await pool.request().input('cid', sql.Int, customer.CustomerID).input('bal', sql.Decimal(12,2), customer.WalletBalance - total)
                .query('UPDATE Customer SET WalletBalance = @bal WHERE CustomerID = @cid');
        }

        const insertRes = await pool.request()
            .input('customerId', sql.Int, customer.CustomerID)
            .input('roomId', sql.Int, roomId)
            .input('checkIn', sql.Date, checkIn)
            .input('checkOut', sql.Date, checkOut)
            .input('total', sql.Decimal(12,2), total)
            .input('method', sql.VarChar, method)
            .query(`
                INSERT INTO Reservation (CustomerID, RoomID, CheckInDate, CheckOutDate, TotalAmount, PaymentMethod)
                VALUES (@customerId, @roomId, @checkIn, @checkOut, @total, @method);
                SELECT SCOPE_IDENTITY() AS ReservationID
            `);
        const bookingId = insertRes.recordset[0].ReservationID;

        // Mark room occupied
        await pool.request().input('roomId', sql.Int, roomId).query(`UPDATE Room SET Status='Occupied' WHERE RoomID=@roomId`);

        // Create payment record
        await pool.request()
            .input('bookingId', sql.Int, bookingId)
            .input('amount', sql.Decimal(12,2), total)
            .input('method', sql.VarChar, method)
            .input('status', sql.VarChar, method === 'Wallet' ? 'Paid' : 'Pending')
            .query(`INSERT INTO Payment (ReservationID, Amount, PaymentMethod, Status, PaymentDate) VALUES (@bookingId, @amount, @method, @status, GETDATE())`);

        res.json({ bookingId, total, message: 'Booking created successfully' });
    } catch(err) { console.error(err); res.status(500).json({ message: err.message }); }
});

// Check-in
app.post('/api/bookings/:id/checkin', auth, staffOnly, async (req, res) => {
    try {
        const pool = await getPool();
        await pool.request().input('id', sql.Int, req.params.id)
            .query(`UPDATE Reservation SET Status='Checked In' WHERE ReservationID=@id AND Status='Confirmed'`);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// Check-out
app.post('/api/bookings/:id/checkout', auth, staffOnly, async (req, res) => {
    try {
        const pool = await getPool();
        // Get room ID from booking to free it up
        const bk = await pool.request().input('id', sql.Int, req.params.id)
            .query(`SELECT RoomID FROM Reservation WHERE ReservationID=@id`);
        if (bk.recordset.length) {
            await pool.request().input('roomId', sql.Int, bk.recordset[0].RoomID)
                .query(`UPDATE Room SET Status='Available' WHERE RoomID=@roomId`);
        }
        await pool.request().input('id', sql.Int, req.params.id)
            .query(`UPDATE Reservation SET Status='Completed' WHERE ReservationID=@id AND Status='Checked In'`);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// Cancel booking (80% refund)
app.post('/api/bookings/:id/cancel', auth, async (req, res) => {
    try {
        const pool = await getPool();
        const bk = await pool.request().input('id', sql.Int, req.params.id)
            .query(`SELECT r.ReservationID, r.TotalAmount, r.RoomID, r.PaymentMethod, c.CustomerID, c.WalletBalance
                    FROM Reservation r JOIN Customer c ON r.CustomerID=c.CustomerID
                    WHERE r.ReservationID=@id AND r.Status IN ('Confirmed','Checked In')`);
        if (!bk.recordset.length) return res.status(400).json({ message: 'Booking cannot be cancelled' });
        const b = bk.recordset[0];
        // Refund 80% to wallet
        const refund = Math.round(b.TotalAmount * 0.8 * 100) / 100;
        await pool.request().input('cid', sql.Int, b.CustomerID).input('bal', sql.Decimal(12,2), b.WalletBalance + refund)
            .query('UPDATE Customer SET WalletBalance=@bal WHERE CustomerID=@cid');
        await pool.request().input('id', sql.Int, req.params.id)
            .query(`UPDATE Reservation SET Status='Cancelled' WHERE ReservationID=@id`);
        await pool.request().input('roomId', sql.Int, b.RoomID)
            .query(`UPDATE Room SET Status='Available' WHERE RoomID=@roomId`);
        res.json({ success: true, refund });
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// ── PAYMENTS ROUTES ──────────────────────────────────────────────────────
// All payments (staff)
app.get('/api/payments', auth, staffOnly, async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query(`
            SELECT p.PaymentID as id, p.ReservationID as bookingId, p.Amount as amount,
                   p.PaymentMethod as method, p.PaymentDate as date, p.Status as status,
                   c.FullName as guestName
            FROM Payment p
            JOIN Reservation r ON p.ReservationID = r.ReservationID
            JOIN Customer c ON r.CustomerID = c.CustomerID
            ORDER BY p.PaymentDate DESC
        `);
        res.json(result.recordset);
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// My payments (customer)
app.get('/api/payments/my', auth, async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().input('userId', sql.Int, req.userId).query(`
            SELECT p.PaymentID as id, p.ReservationID as bookingId, p.Amount as amount,
                   p.PaymentMethod as method, p.PaymentDate as date, p.Status as status
            FROM Payment p
            JOIN Reservation r ON p.ReservationID = r.ReservationID
            JOIN Customer c ON r.CustomerID = c.CustomerID
            WHERE c.UserID = @userId
            ORDER BY p.PaymentDate DESC
        `);
        res.json(result.recordset);
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// Mark payment as paid
app.put('/api/payments/:id/pay', auth, staffOnly, async (req, res) => {
    try {
        const pool = await getPool();
        await pool.request().input('id', sql.Int, req.params.id)
            .query(`UPDATE Payment SET Status='Paid' WHERE PaymentID=@id`);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// ── WALLET ROUTES ─────────────────────────────────────────────────────────
app.post('/api/wallet/topup', auth, async (req, res) => {
    const { amount } = req.body;
    if (!amount || amount <= 0) return res.status(400).json({ message: 'Invalid amount' });
    try {
        const pool = await getPool();
        const custRes = await pool.request().input('userId', sql.Int, req.userId)
            .query('SELECT CustomerID, WalletBalance FROM Customer WHERE UserID = @userId');
        if (!custRes.recordset.length) return res.status(400).json({ message: 'Customer not found' });
        const { CustomerID, WalletBalance } = custRes.recordset[0];
        const newBalance = WalletBalance + Number(amount);
        await pool.request().input('cid', sql.Int, CustomerID).input('bal', sql.Decimal(12,2), newBalance)
            .query('UPDATE Customer SET WalletBalance=@bal WHERE CustomerID=@cid');
        res.json({ newBalance });
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// ── USERS ROUTES ──────────────────────────────────────────────────────────
// Get all users
app.get('/api/users', auth, staffOnly, async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query(`
            SELECT u.UserID as id, u.Username as username, r.RoleName as role,
                   ISNULL(c.FullName, u.Username) as fullName,
                   c.Email as email, c.Phone as phone,
                   ISNULL(c.WalletBalance, 0) as wallet,
                   c.RegistrationDate as joined
            FROM UserAccount u
            JOIN Role r ON u.RoleID = r.RoleID
            LEFT JOIN Customer c ON u.UserID = c.UserID
            WHERE u.IsActive = 1
            ORDER BY u.UserID
        `);
        res.json(result.recordset);
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// Create staff user (admin only)
app.post('/api/users', auth, adminOnly, async (req, res) => {
    const { fullName, username, email, password, phone, role } = req.body;
    if (!fullName || !username || !email || !password) return res.status(400).json({ message: 'All fields required' });
    try {
        const pool = await getPool();
        const exists = await pool.request().input('username', sql.VarChar, username)
            .query('SELECT UserID FROM UserAccount WHERE Username = @username');
        if (exists.recordset.length) return res.status(400).json({ message: 'Username already taken' });
        // Get role ID
        const roleRes = await pool.request().input('role', sql.VarChar, role || 'receptionist')
            .query('SELECT RoleID FROM Role WHERE RoleName = @role');
        const roleId = roleRes.recordset.length ? roleRes.recordset[0].RoleID : 2;
        const insertUser = await pool.request()
            .input('username', sql.VarChar, username)
            .input('password', sql.VarChar, password)
            .input('roleId', sql.Int, roleId)
            .query(`INSERT INTO UserAccount (RoleID, Username, PasswordHash, IsActive) VALUES (@roleId, @username, @password, 1); SELECT SCOPE_IDENTITY() AS UserID`);
        const userId = insertUser.recordset[0].UserID;
        // Insert Customer record for all users so joins work
        await pool.request()
            .input('userId', sql.Int, userId)
            .input('fullName', sql.NVarChar, fullName)
            .input('email', sql.VarChar, email)
            .input('phone', sql.VarChar, phone || '')
            .query(`INSERT INTO Customer (UserID, FullName, Email, Phone, WalletBalance) VALUES (@userId, @fullName, @email, @phone, 0)`);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// Update current user profile
app.put('/api/users/me', auth, async (req, res) => {
    const { fullName, email, phone, password } = req.body;
    if (!fullName || !email) return res.status(400).json({ message: 'Name and email required' });
    try {
        const pool = await getPool();
        await pool.request()
            .input('userId', sql.Int, req.userId)
            .input('fullName', sql.NVarChar, fullName)
            .input('email', sql.VarChar, email)
            .input('phone', sql.VarChar, phone || '')
            .query(`UPDATE Customer SET FullName=@fullName, Email=@email, Phone=@phone WHERE UserID=@userId`);
        if (password) {
            await pool.request().input('userId', sql.Int, req.userId).input('password', sql.VarChar, password)
                .query(`UPDATE UserAccount SET PasswordHash=@password WHERE UserID=@userId`);
        }
        res.json({ success: true });
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// Delete user
app.delete('/api/users/:id', auth, adminOnly, async (req, res) => {
    try {
        const pool = await getPool();
        await pool.request().input('id', sql.Int, req.params.id)
            .query(`UPDATE UserAccount SET IsActive=0 WHERE UserID=@id`);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// ── COMPLAINTS ROUTES ─────────────────────────────────────────────────────
// All complaints (staff)
app.get('/api/complaints', auth, staffOnly, async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query(`
            SELECT c.ComplaintID as id, c.Subject as category, c.Description as message,
                   c.ComplaintDate as date, c.Status as status,
                   cu.FullName as userName
            FROM Complaint c
            JOIN Customer cu ON c.CustomerID = cu.CustomerID
            ORDER BY c.ComplaintDate DESC
        `);
        res.json(result.recordset);
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// My complaints
app.get('/api/complaints/my', auth, async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().input('userId', sql.Int, req.userId).query(`
            SELECT ComplaintID as id, Subject as category, Description as message,
                   ComplaintDate as date, Status as status
            FROM Complaint
            WHERE CustomerID = (SELECT CustomerID FROM Customer WHERE UserID = @userId)
            ORDER BY ComplaintDate DESC
        `);
        res.json(result.recordset);
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// Submit complaint
app.post('/api/complaints', auth, async (req, res) => {
    const { message, category } = req.body;
    if (!message) return res.status(400).json({ message: 'Message is required' });
    try {
        const pool = await getPool();
        const custRes = await pool.request().input('userId', sql.Int, req.userId)
            .query('SELECT CustomerID FROM Customer WHERE UserID = @userId');
        if (!custRes.recordset.length) return res.status(400).json({ message: 'Customer not found' });
        await pool.request()
            .input('customerId', sql.Int, custRes.recordset[0].CustomerID)
            .input('subject', sql.NVarChar, category || 'General')
            .input('description', sql.NVarChar, message)
            .query(`INSERT INTO Complaint (CustomerID, Subject, Description, ComplaintDate, Status) VALUES (@customerId, @subject, @description, GETDATE(), 'Pending')`);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// ── NOTIFICATIONS ROUTES ──────────────────────────────────────────────────
app.get('/api/notifications', auth, async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().input('userId', sql.Int, req.userId).query(`
            SELECT NotificationID as id, Message as message, NotificationDate as date, IsRead as read
            FROM Notification
            WHERE CustomerID = (SELECT CustomerID FROM Customer WHERE UserID = @userId)
            ORDER BY NotificationDate DESC
        `);
        await pool.request().input('userId', sql.Int, req.userId).query(`
            UPDATE Notification SET IsRead=1 WHERE CustomerID=(SELECT CustomerID FROM Customer WHERE UserID=@userId) AND IsRead=0
        `);
        res.json(result.recordset);
    } catch(err) { res.status(500).json({ message: err.message }); }
});

app.delete('/api/notifications', auth, async (req, res) => {
    try {
        const pool = await getPool();
        await pool.request().input('userId', sql.Int, req.userId)
            .query(`DELETE FROM Notification WHERE CustomerID=(SELECT CustomerID FROM Customer WHERE UserID=@userId)`);
        res.json({ success: true });
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// ── REPORTS ROUTE ─────────────────────────────────────────────────────────
app.get('/api/reports', auth, staffOnly, async (req, res) => {
    try {
        const pool = await getPool();
        const revRes = await pool.request().query(`
            SELECT ISNULL(SUM(p.Amount), 0) as totalRevenue, COUNT(DISTINCT r.ReservationID) as totalBookings
            FROM Reservation r
            LEFT JOIN Payment p ON r.ReservationID = p.ReservationID AND p.Status = 'Paid'
        `);
        const typeRes = await pool.request().query(`
            SELECT rt.TypeName as type, ISNULL(SUM(p.Amount), 0) as revenue
            FROM RoomType rt
            LEFT JOIN Room ro ON rt.RoomTypeID = ro.RoomTypeID
            LEFT JOIN Reservation r ON ro.RoomID = r.RoomID
            LEFT JOIN Payment p ON r.ReservationID = p.ReservationID AND p.Status = 'Paid'
            GROUP BY rt.TypeName
        `);
        const statusRes = await pool.request().query(`
            SELECT Status, COUNT(*) as cnt FROM Reservation GROUP BY Status
        `);
        const occRes = await pool.request().query(`
            SELECT
                CAST(SUM(CASE WHEN Status='Occupied' THEN 1 ELSE 0 END) AS FLOAT) / NULLIF(COUNT(*),0) * 100 as occupancy
            FROM Room
        `);
        const revenueByType = {};
        typeRes.recordset.forEach(r => { revenueByType[r.type] = r.revenue; });
        const statusCounts = {};
        statusRes.recordset.forEach(r => { statusCounts[r.Status] = r.cnt; });
        res.json({
            totalRevenue: revRes.recordset[0].totalRevenue,
            totalBookings: revRes.recordset[0].totalBookings,
            revenueByType,
            statusCounts,
            occupancy: Math.round(occRes.recordset[0].occupancy || 0)
        });
    } catch(err) { res.status(500).json({ message: err.message }); }
});

// ── START SERVER ──────────────────────────────────────────────────────────
const PORT = process.env.PORT || 5000;
async function startServer() {
    try {
        await getPool();
        app.listen(PORT, () => {
            console.log(`🚀 Server running on port ${PORT}`);
            console.log(`📡 API: http://localhost:${PORT}/api`);
        });
    } catch(err) {
        console.error('❌ DB connection failed:', err.message);
        process.exit(1);
    }
}
startServer();
